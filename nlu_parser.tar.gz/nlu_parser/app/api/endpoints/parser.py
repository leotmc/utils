from fastapi import APIRouter
from app.schema.input_text import InputText
from app.schema.parsed_result import ParsedResult
from nlu.run import interpreter

router = APIRouter()


@router.post('/model/parse/', response_model=ParsedResult)
def nlu_parse(text: InputText):
    parsed_result = interpreter.parse(text.text)
    return ParsedResult(**parsed_result)
