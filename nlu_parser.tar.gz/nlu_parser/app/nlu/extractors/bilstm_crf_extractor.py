import os
import json
import requests
import numpy as np
import tensorflow_addons as tfa
from scipy.special import softmax
from typing import Optional, Text, Dict, Any, List
from app.nlu.extractors import EntityExtractor
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata
from app.nlu.utils.io import read_json_file
from app.config import (
    tf_serving_host,
    tf_serving_port,
    entity_recognization_model_name
)


class BiLSTMCRFExtractor(EntityExtractor):

    provides = ["entities"]

    defaults = {
        'serving_host': tf_serving_host,
        'serving_port': tf_serving_port,
        'model_name': entity_recognization_model_name,
        'confidence_threshold': 0.5
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ['tensorflow_addons', 'requests']

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            index2label: Optional[Dict[int, Any]] = None,
            char2index: Optional[Dict[Text, int]] = None,
            transition_params: Optional[np.ndarray] = None
    ):
        super(BiLSTMCRFExtractor, self).__init__(component_config)
        self.index2label = index2label
        self.char2index = char2index
        self.transition_params = transition_params
        self.max_seq_length = component_config['max_seq_length']
        self.serving_url = f'http://{self.component_config["serving_host"]}:{self.component_config["serving_port"]}/v1/models/{self.component_config["model_name"]}:predict'

    def process(self, message: Message, **kwargs: Any) -> None:
        logits, num_tokens = self.predict(message)
        extracted = self.add_extractor_name(self.decode(logits, num_tokens, message))
        message.set(
            "entities",
            message.get("entities", []) + extracted,
            add_to_output=True
        )

    def predict(self, message: Message):
        query = message.text
        inputs = [self.char2index.get(c, 0) for c in query]
        inputs = inputs + [0] * (self.max_seq_length - len(inputs)) if len(inputs) < self.max_seq_length else inputs[:self.max_seq_length]
        instances = [{'input_1': inputs}]
        data = json.dumps({'signature_name': 'serving_default', 'instances': instances})
        response = requests.post(self.serving_url, data=data, headers={'content-type': 'application/json'})
        predictions = json.loads(response.text)['predictions']
        return np.array(predictions[0]['output_1']), predictions[0]['output_2']

    def decode(self, logits, num_tokens, message):
        viterbi_path, viterbi_score = tfa.text.viterbi_decode(logits[:num_tokens], self.transition_params)
        predict_labels = [self.index2label[index] for index in viterbi_path]
        results = []
        start_pos, end_pos, entity = None, None, None
        for i, label in enumerate(predict_labels):
            if label.startswith('B'):
                if start_pos is None:
                    start_pos = i
                    entity = label.split('-')[-1]
                else:
                    end_pos = i - 1
                    results.append({'start': start_pos, 'end': end_pos, 'value': message.text[start_pos: i], 'entity': entity})
                    entity = label.split('-')[-1]
                    start_pos, end_pos = i, None
            elif label == 'O' and start_pos is not None:
                end_pos = i - 1
                results.append({'start': start_pos, 'end': end_pos, 'value': message.text[start_pos: i], 'entity': entity})
                start_pos, end_pos = None, None
        if start_pos is not None:
            end_pos = num_tokens - 1
            results.append({'start': start_pos, 'end': end_pos, 'value': message.text[start_pos: num_tokens], 'entity': entity})
        # Calculate the probability of extracted entities
        tag_probabilities = softmax(logits[:num_tokens, ], axis=-1)
        for i, e in enumerate(results):
            entity_probabilities = []
            for j in range(e['start'], e['end'] + 1):
                entity_probabilities.append(tag_probabilities[j, viterbi_path[j]])
            entity_probability = np.exp(np.sum(np.log(entity_probabilities)))
            results[i]['confidence'] = entity_probability
        return [item for item in results if item['confidence'] > self.component_config['confidence_threshold']]

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["BiLSTMCRFExtractor"] = None,
            **kwargs
    ):
        component_model_dir = os.path.join(model_dir, meta['name'])
        index_label_mapping_file = os.path.join(component_model_dir, meta["index_label_mapping_file"])
        char_index_mapping_file = os.path.join(component_model_dir, meta["char_index_mapping_file"])
        transition_param_file = os.path.join(component_model_dir, meta["transition_param_file"])
        index2label = read_json_file(index_label_mapping_file)
        index2label = {int(index): label for index, label in index2label.items()}
        char2index = read_json_file(char_index_mapping_file)
        transition_params = np.load(transition_param_file)
        return cls(meta, index2label, char2index, transition_params)
