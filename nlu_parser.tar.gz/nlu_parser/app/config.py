import os
from configparser import ConfigParser

root_path = os.path.dirname(__file__)
data_path = os.path.join(root_path, '../data')
log_path = os.path.join(root_path, '../logs')
conf_path = os.path.join(root_path, '../conf')
nlu_model_path = os.path.join(root_path, '../models')
nlu_path = os.path.join(root_path, 'nlu')
config_file = os.path.join(conf_path, 'nlu.conf')
nlu_config_file = os.path.join(nlu_path, 'config.yml')
nlu_domain_file = os.path.join(nlu_path, 'domain.yml')
nlu_data_path = os.path.join(data_path, 'nlu')

conf = ConfigParser()
conf.read([config_file])
module_name = conf.get('DEFAULT', 'module_name')

bert_vocab_file = os.path.join(data_path, conf.get('DATA', 'bert_vocab_file'))
bilstm_crf_vocab_file = os.path.join(data_path, conf.get('DATA', 'bilstm_crf_vocab_file'))

# tf serving
tf_serving_host = conf.get('TF_SERVING', 'host')
tf_serving_port = conf.getint('TF_SERVING', 'port')
entity_recognization_model_name = conf.get('TF_SERVING', 'entity_recognization_model_name')
intent_classification_model_name = conf.get('TF_SERVING', 'intent_classification_model_name')
