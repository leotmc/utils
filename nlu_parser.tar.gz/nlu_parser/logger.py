import logging
import os
from logging import handlers
import config


def _get_logger(name):
    formatter = logging.Formatter('[%(levelname)s] - [%(asctime)s] - [%(filename)s:%(lineno)d] - [%(message)s]')
    nor_file_name = os.path.join(config.log_path, name)
    abnormal_file_name = os.path.join(config.log_path, name + '.wf')

    # normal log
    handler_nor = handlers.TimedRotatingFileHandler(filename=nor_file_name, when='D', backupCount=360)
    handler_nor.setFormatter(formatter)
    handler_nor.setLevel(logging.INFO)

    # abnormal log
    handler_wf = handlers.TimedRotatingFileHandler(filename=abnormal_file_name, when='D', backupCount=360)
    handler_wf.setFormatter(formatter)
    handler_wf.setLevel(logging.WARNING)

    # console
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.setLevel(logging.DEBUG)

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler_nor)
    logger.addHandler(handler_wf)
    logger.addHandler(console)
    return logger


logger = _get_logger(config.module_name)
