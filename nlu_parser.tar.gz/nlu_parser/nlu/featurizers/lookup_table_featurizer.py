import os
import typing
import numpy as np
from typing import Any, Text, Optional, Dict
from nlu.training_data.message import Message
from nlu.utils import util
from nlu.utils.trie import search_by_trie
from nlu.featurizers import Featurizer
from nlu.constants import (
    MESSAGE_TEXT_ATTRIBUTE,
    MESSAGE_VECTOR_FEATURE_NAMES
)

if typing.TYPE_CHECKING:
    from nlu.model import Metadata
    from dawg import IntDAWG


class LookupTableFeaturizer(Featurizer):

    provides = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            trie_map: Optional[Dict[Text, "IntDAWG"]] = None,
    ) -> None:
        super(LookupTableFeaturizer, self).__init__(component_config)
        self.trie_map = trie_map if trie_map else dict()

    def process(self, message: Message, **kwargs: Any):
        updated = self._text_features_with_lookup_table(message)
        message.set(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE], updated)

    def _text_features_with_lookup_table(self, message):
        if self.trie_map:
            extras = self.features_for_lookup_table(message)
            return self._combine_with_existing_features(message, extras)
        else:
            return message.get(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE])

    def features_for_lookup_table(self, message):
        found_patterns = []
        for intent, trie in self.trie_map.items():
            hits = search_by_trie(message.text, trie)
            if hits:
                found_patterns.append(True)
            else:
                found_patterns.append(False)
        return np.array(found_patterns).astype(float)

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["LookupTableFeaturizer"] = None,
            **kwargs: Any
    ) -> "LookupTableFeaturizer":
        file_name = meta.get("file")
        trie_map_file = os.path.join(model_dir, file_name)
        trie_map = util.json_unpickle(trie_map_file)
        return LookupTableFeaturizer(meta, trie_map=trie_map)
