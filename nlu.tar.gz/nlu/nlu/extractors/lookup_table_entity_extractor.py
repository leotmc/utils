import os
import typing
import warnings
from typing import Optional, Dict, Text, Any, List
from nlu.extractors import EntityExtractor
from nlu.utils.util import json_pickle, json_unpickle
from nlu.training_data.data import TrainingData
from nlu.training_data.message import Message
from nlu.model import Metadata
from nlu.nlu_config import RasaNLUModelConfig
from nlu.utils.trie import build_trie, search_by_trie


if typing.TYPE_CHECKING:
    from dawg import IntDAWG


class LookupTableEntityExtractor(EntityExtractor):
    
    provides = ["entities"]
    
    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            trie_map: Optional[Dict[Text, "IntDAWG"]] = None,
            
    ):
        super(LookupTableEntityExtractor, self).__init__(component_config)
        self.trie_map = trie_map if trie_map else dict()
    
    def train(
            self, training_data: TrainingData, config: RasaNLUModelConfig, **kwargs: Any
    ) -> None:
        self._build_trie_map(training_data.entity_lookup_tables)

    def process(self, message: Message, **kwargs: Any) -> None:
        extracted = self.add_extractor_name(self.extract_entities(message))
        message.set(
            "entities",
            message.get("entities", []) + extracted,
            add_to_output=True
        )

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
        Return the metadata necessary to load the model again."""
        file_name = file_name + ".pkl"
        trie_map_file = os.path.join(model_dir, file_name)
        json_pickle(trie_map_file, self.trie_map)
        return {"file": file_name}

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["LookupTableEntityExtractor"] = None,
            **kwargs: Any,
    ) -> "LookupTableEntityExtractor":
        file_name = meta["file"]
        trie_map_file = os.path.join(model_dir, file_name)
        if os.path.exists(trie_map_file):
            trie_map = json_unpickle(trie_map_file)
            return cls(meta, trie_map)
        else:
            warnings.warn("Failed to load trie map file from '{}'".format(trie_map_file))
            return cls(meta)

    def extract_entities(self, message: Message) -> List[Dict[Text, Any]]:
        """Take a sentence and return entities in json format"""
        entities = []
        for slot, trie in self.trie_map.items():
            hits = search_by_trie(message.text, trie)
            if not hits:
                continue
            value, start, end = hits[0]
            entities.append({
                "start": start,
                "end": end,
                "value": value,
                "entity": slot,
                "confidence": 1.0
            })
        return entities

    def _build_trie_map(self, lookup_tables: List[Dict[Text, Any]]):
        for table in lookup_tables:
            name = table["name"]
            elements = table["elements"]
            trie = build_trie(elements)
            self.trie_map[name] = trie
