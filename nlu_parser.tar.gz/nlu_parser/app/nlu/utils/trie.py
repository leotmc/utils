from dawg import IntDAWG


def build_trie(tokens):
    return IntDAWG([(t, i) for i, t in enumerate(tokens)])


def search_by_trie(text, trie):
    i = 0
    hits = []
    while i < len(text):
        word = _longest_prefix(text[i:], trie)
        if word:
            hits.append((word, i, i + len(word) - 1))
            i += len(word)
        else:
            i += 1
    return hits


def _longest_prefix(text, trie):
    word = ''
    wsize = 0
    for w in trie.prefixes(text):  # 找到text在trie中的所有前缀
        if len(w) > wsize:
            word = w
    return word


def save_trie(trie, path):
    trie.save(path)
