import math
import torch
import editdistance
from scipy.spatial.distance import cosine, cdist
from transformers import AutoModel, AutoTokenizer
from app.config import simcse_pt_model_dir

tokenizer = AutoTokenizer.from_pretrained(simcse_pt_model_dir)
model = AutoModel.from_pretrained(simcse_pt_model_dir)


def get_embeddings(sentences, batch_size=32):
    num_sentences = len(sentences)
    num_batches = math.ceil(num_sentences / batch_size)
    embeddings = []
    for i in range(num_batches):
        batch_sentences = sentences[i * batch_size: min((i + 1) * batch_size, num_sentences)]
        batch_inputs = tokenizer(batch_sentences, max_length=512, padding=True, truncation=True, return_tensors='pt')
        with torch.no_grad():
            batch_embeddings = model(**batch_inputs, output_hidden_states=True, return_dict=True).pooler_output.numpy()
            embeddings.extend(batch_embeddings)
    return embeddings


def cosine_similarity(embedding1, embedding2):
    similarity = 1 - cosine(embedding1, embedding2)
    return similarity


def matrix_cosine_similarity(m1, m2, metric='cosine'):
    return 1.0 - cdist(m1, m2, metric=metric)


def string_similarity(text, compare_text):
    edit_distance = editdistance.eval(text, compare_text)
    return 1 - 1.0 * edit_distance / max([len(text), len(compare_text)])


if __name__ == '__main__':

    embeddings_a = get_embeddings(
        sentences=["今天天气真好", "你好", "今天的天气挺不错的"],
        batch_size=4
    )
    embeddings_b = get_embeddings(
        sentences=["今天天气真好", "你好", "今天的天气挺不错的"],
        batch_size=4
    )
    similarities = matrix_cosine_similarity(embeddings_a, embeddings_b)

