from nlu.nlu_config import load
from typing import Text, Any
from nlu.training_data.loading import load_data
from nlu.utils.io import read_config_file
from nlu.utils.util import model_fingerprint, fingerprint_from_path, fingerprint_changed, persist_fingerprint
from nlu.model import Trainer, Interpreter
from config import nlu_data_path, nlu_config_file, nlu_model_path


def create_interpreter(
        config_file: Text,
        model_path: Text,
        data_path: Text,
        **kwargs: Any
):
    training_data = load_data(data_path)
    training_data.print_stats()
    conf = read_config_file(config_file)
    conf = load(conf)
    new_fingerprint = model_fingerprint(conf.as_dict(), training_data)
    if should_retrain(model_path, new_fingerprint):
        trainer = Trainer(conf)
        interpreter = trainer.train(training_data, **kwargs)
        trainer.persist(model_path)
        persist_fingerprint(model_path, new_fingerprint)
    else:
        interpreter = Interpreter.load(model_path)
    return interpreter


def should_retrain(model_path, new_fingerprint):
    old_fingerprint = fingerprint_from_path(model_path)
    return fingerprint_changed(old_fingerprint, new_fingerprint)


interpreter = create_interpreter(nlu_config_file, nlu_model_path, nlu_data_path)

