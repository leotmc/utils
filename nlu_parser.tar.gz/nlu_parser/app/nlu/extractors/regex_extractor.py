import os
import re
from typing import Optional, Text, Dict, List, Any
from app.nlu.extractors import EntityExtractor
from app.nlu.utils.util import read_json_file
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata


class RegexExtractor(EntityExtractor):

    provides = ["entities"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns=None
    ):
        super(RegexExtractor, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def process(self, message: Message, **kwargs: Any) -> None:
        extracted = self.add_extractor_name(self.extract_entities(message))
        message.set(
            "entities",
            message.get("entities", []) + extracted,
            add_to_output=True
        )

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Text = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["RegexExtractor"] = None,
            **kwargs: Any,
    ) -> "RegexExtractor":
        component_model_dir = os.path.join(model_dir, meta['name'])
        pattern_file = os.path.join(component_model_dir, meta['pattern_file'])
        if os.path.exists(pattern_file):
            known_patterns = read_json_file(pattern_file)
            return RegexExtractor(meta, known_patterns)
        else:
            return RegexExtractor(meta)

    def extract_entities(self, message: Message) -> List[Dict[Text, Any]]:
        return self.entities_for_patterns(message)

    def entities_for_patterns(self, message: Message) -> List[Dict[Text, Any]]:
        entities = []
        for exp in self.known_patterns:
            matches = re.finditer(exp["pattern"], message.text)
            matches = list(matches)
            for match in matches:
                entities.append({
                    "start": match.start(),
                    "end": match.end() - 1,
                    "value": match.group(),
                    "entity": exp["name"],
                    "confidence": 1.0
                })
        return entities

