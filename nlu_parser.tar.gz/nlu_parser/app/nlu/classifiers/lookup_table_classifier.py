import os
import typing
from typing import Optional, Dict, Text, Any
from app.nlu.utils import util
from app.nlu.classifiers import IntentClassifier
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata
from app.nlu.utils.trie import search_by_trie


if typing.TYPE_CHECKING:
    from dawg import IntDAWG


class LookupTableClassifier(IntentClassifier):

    provides = ["intent"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            tries: Optional[Dict[Text, "IntDAWG"]] = None,
    ):
        super(LookupTableClassifier, self).__init__(component_config)
        self.tries = tries if tries else dict()

    def process(self, message: Message, **kwargs: Any) -> None:
        for intent_name, trie in self.tries.items():
            hits = search_by_trie(message.text, trie)
            if hits:
                intent = {"name": intent_name, "confidence": 1.0, "recognizer": self.name}
                message.set("intent", intent, add_to_output=True)
                message.set('intent_ranking', [])

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["LookupTableClassifier"] = None,
            **kwargs: Any
    ):
        component_model_dir = os.path.join(model_dir, meta['name'])
        trie_file = os.path.join(component_model_dir, meta["trie_file"])
        tries = util.json_unpickle(trie_file)
        return LookupTableClassifier(meta, tries)
