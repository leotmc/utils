import math
import torch
import numpy as np
from scipy.special import softmax
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from app.utils.io_util import (
    complaint_label_category_mapping,
    department_label_category_mapping
)
from app.constants import Task
from app.exceptions import InvalidTask
from app.core.model_server import model_server
from app.config import complaint_classification_pt_model_dir, department_classification_pt_model_dir


class Classifier(object):

    def classify(self, task, size, queries, batch_size=32):
        if task == Task.COMPLAINT_CLASSIFICATION.value:
            return self._classify(task, queries, complaint_label_category_mapping, size, batch_size=batch_size)
        elif task == Task.DEPARTMENT_CLASSIFICATION.value:
            return self._classify(task, queries, department_label_category_mapping, size, batch_size=batch_size)
        else:
            raise InvalidTask()

    def _classify(self, task, queries, label2category, size, batch_size):
        raise NotImplementedError


class PTClassifier(Classifier):

    def __init__(self):
        self.complaint_classification_tokenizer = AutoTokenizer.from_pretrained(complaint_classification_pt_model_dir)
        self.department_classification_tokenizer = AutoTokenizer.from_pretrained(department_classification_pt_model_dir)
        self.complaint_classification_model = AutoModelForSequenceClassification.from_pretrained(complaint_classification_pt_model_dir)
        self.department_classification_model = AutoModelForSequenceClassification.from_pretrained(department_classification_pt_model_dir)

    def _classify(self, task, queries, label2category, size, batch_size):
        num_queries = len(queries)
        num_batches = math.ceil(num_queries / batch_size)
        tokenizer = self.complaint_classification_tokenizer if task == Task.COMPLAINT_CLASSIFICATION.value else self.department_classification_tokenizer
        model = self.complaint_classification_model if task == Task.COMPLAINT_CLASSIFICATION.value else self.department_classification_model
        for i in range(num_batches):
            batch_queries = queries[i * batch_size: min((i + 1) * batch_size, num_queries)]
            batch_inputs = tokenizer(batch_queries, max_length=512, padding=True, truncation=True, return_tensors='pt')
            with torch.no_grad():
                batch_inputs = model(**batch_inputs, output_hidden_states=True, return_dict=True)


class TFServingClassifier(Classifier):

    def _classify(self, task, queries, label2category, size, batch_size):
        samples = [f"{query['complaint']}-{query['address']}" if task == Task.DEPARTMENT_CLASSIFICATION.value and query.get('address')
                   else query['complaint'] for query in queries]
        res = model_server.serve(
            samples=samples,
            task=task,
            batch_size=batch_size
        )
        probabilities = softmax(res)
        sorted_indices = np.argsort(-probabilities, axis=1)
        res = []
        for i in range(sorted_indices.shape[0]):
            indices = sorted_indices[i, :]
            topk_probabilities = [probabilities[0][ind] for ind in indices[:size]]
            topk_labels = [label2category[str(ind)] for ind in indices[:size]]
            res.append([{'confidence': probability, 'label': label} for probability, label in zip(topk_probabilities, topk_labels)])
        return res


classifier = TFServingClassifier()


if __name__ == '__main__':
    res = classifier.classify(
        task='complaint_classification',
        size=5,
        queries=[
            {
                "complaint": "老板无故辞退其，还拿走手机，需要解决，协同政府。",
                "address": "宝安区西乡街道新安第二工业区4栋5楼"
            },
            {
                "complaint": "店门口的垃圾无人清扫。",
                "address": "宝安区沙井广深公路367号深会大厦门口"
            },
            {
                "complaint": "被妻子殴打，无需急救。",
                "address": "宝安区鹤州新村7巷4号"
            },
            {
                "complaint": "施工噪音扰民，联系12369无果，需处理",
                "address": "宝安区航城街道黄麻布泰安路6号"
            },
            {
                "complaint": "因小区封控，外面使用红色铁马围起来，现在不清楚什么原因倒下来，可能是人推的也可能是风刮的。",
                "address": "宝安区宝安中心天悦龙庭与尚都花园之间"
            }
        ]
    )
    print(res)
