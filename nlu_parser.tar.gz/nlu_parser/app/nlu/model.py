import datetime
import logging
import os
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Text

from app.nlu import components
from app.nlu.components import Component, ComponentBuilder
from app.nlu.nlu_config import component_config_from_pipeline
from app.nlu.training_data.message import Message
from app.nlu.utils.util import write_json_to_file, read_json_file

MODEL_NAME_PREFIX = "nlu_"

logger = logging.getLogger(__name__)


class InvalidModelError(Exception):
    """Raised when a model failed to load.
    Attributes:
        message -- explanation of why the model is invalid
    """

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class UnsupportedModelError(Exception):
    """Raised when a model is too old to be loaded.
    Attributes:
        message -- explanation of why the model is invalid
    """

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class Metadata(object):
    """Captures all information about a model to load and prepare it."""

    @staticmethod
    def load(model_dir: Text):
        """Loads the metadata from a models directory.
        Args:
            model_dir: the directory where the model is saved.
        Returns:
            Metadata: A metadata object describing the model
        """
        try:
            metadata_file = os.path.join(model_dir, "metadata.json")
            data = read_json_file(metadata_file)
            return Metadata(data, model_dir)
        except Exception as e:
            abspath = os.path.abspath(os.path.join(model_dir, "metadata.json"))
            raise InvalidModelError(
                "Failed to load model metadata from '{}'. {}".format(abspath, e)
            )

    def __init__(self, metadata: Dict[Text, Any], model_dir: Optional[Text]):

        self.metadata = metadata
        self.model_dir = model_dir

    def get(self, property_name, default=None):
        return self.metadata.get(property_name, default)

    @property
    def component_classes(self):
        if self.get("pipeline"):
            return [c.get("class") for c in self.get("pipeline", [])]
        else:
            return []

    @property
    def number_of_components(self):
        return len(self.get("pipeline", []))

    def for_component(self, index, defaults=None):
        return component_config_from_pipeline(index, self.get("pipeline", []), defaults)

    @property
    def language(self) -> Optional[Text]:
        """Language of the underlying model"""

        return self.get("language")

    def persist(self, model_dir: Text):
        """Persists the metadata of a model to a given directory."""

        metadata = self.metadata.copy()

        metadata.update(
            {
                "trained_at": datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
            }
        )

        filename = os.path.join(model_dir, "metadata.json")
        write_json_to_file(filename, metadata, indent=4)


class Interpreter(object):
    """Use a trained pipeline of components to parse text messages."""

    def __init__(
            self,
            pipeline: List[Component],
            context: Optional[Dict[Text, Any]],
            model_metadata: Optional[Metadata] = None,
    ):
        self.pipeline = pipeline
        self.context = context if context is not None else {}
        self.model_metadata = model_metadata

    @staticmethod
    def load(
            model_dir: Text,
            component_builder: Optional[ComponentBuilder] = None,
            skip_validation: bool = False,
    ) -> "Interpreter":
        """Create an interpreter based on a persisted model.
        Args:
            skip_validation: If set to `True`, tries to check that all
                required packages for the components are installed
                before loading them.
            model_dir: The path of the model to load
            component_builder: The
                :class:`rasa.nlu.components.ComponentBuilder` to use.
        Returns:
            An interpreter that uses the loaded model.
        """
        model_metadata = Metadata.load(model_dir)
        return Interpreter.create(model_metadata, component_builder, skip_validation)

    @staticmethod
    def create(
            model_metadata: Metadata,
            component_builder: Optional[ComponentBuilder] = None,
            skip_validation: bool = False
    ) -> "Interpreter":
        """Load stored model and components defined by the provided metadata."""
        context = {}
        if component_builder is None:
            # If no builder is passed, every interpreter creation will result
            # in a new builder. hence, no components are reused.
            component_builder = components.ComponentBuilder()
        pipeline = []

        # Before instantiating the component classes,
        # lets check if all required packages are available
        if not skip_validation:
            components.validate_requirements(model_metadata.component_classes)
        for i in range(model_metadata.number_of_components):
            component_meta = model_metadata.for_component(i)
            component = component_builder.load_component(
                component_meta, model_metadata.model_dir, model_metadata, **context
            )
            try:
                updates = component.provide_context()
                if updates:
                    context.update(updates)
                pipeline.append(component)
            except components.MissingArgumentError as e:
                raise Exception(
                    "Failed to initialize component '{}'."
                    "{}".format(component.name, e)
                )
        return Interpreter(pipeline, context, model_metadata)

    def parse(
            self,
            text: Text,
            time: Optional[datetime.datetime] = None,
            only_output_properties: bool = True,
    ) -> Dict[Text, Any]:
        """Parse the input text, classify it and return pipeline result.
        The pipeline result usually contains intent and entities."""
        if not text:
            # Not all components are able to handle empty strings. So we need
            # to prevent that... This default return will not contain all
            # output attributes of all components, but in the end, no one
            # should pass an empty string in the first place.
            output = self.default_output_attributes()
            output["text"] = ""
            return output

        message = Message(text, self.default_output_attributes(), time=time)
        for component in self.pipeline:
            component.process(message, **self.context)
        output = self.default_output_attributes()
        message_dict = message.as_dict(only_output_properties=only_output_properties)
        output.update(message_dict)
        return output

    # Defines all attributes (& default values)
    # that will be returned by `parse`
    @staticmethod
    def default_output_attributes() -> Dict[Text, Any]:
        return {"intent": {"name": None, "confidence": 0.0, "recognizer": None}, "entities": []}
