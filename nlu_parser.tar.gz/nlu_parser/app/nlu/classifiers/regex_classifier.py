import os
import re
from typing import Optional, List, Dict, Text, Any
from app.nlu.utils.io import read_json_file
from app.nlu.classifiers import IntentClassifier
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata


class RegexClassifier(IntentClassifier):

    provides = ["intent"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns: Optional[List[Dict[Text, Text]]] = None,
    ):
        super(RegexClassifier, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def process(self, message: Message, **kwargs: Any) -> None:
        for exp in self.known_patterns:
            match = re.search(exp["pattern"], message.text)
            if match is not None:
                intent = {"name": exp["name"], "confidence": 1.0, "recognizer": self.name}
                message.set("intent", intent, add_to_output=True)
                message.set('intent_ranking', [])

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["RegexClassifier"] = None,
            **kwargs: Any
    ):
        component_model_dir = os.path.join(model_dir, meta['name'])
        pattern_file = os.path.join(component_model_dir, meta["pattern_file"])
        if os.path.exists(pattern_file):
            known_patterns = read_json_file(pattern_file)
            return RegexClassifier(meta, known_patterns=known_patterns)
        else:
            return RegexClassifier(meta)
