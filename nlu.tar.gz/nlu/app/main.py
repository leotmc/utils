from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from app.api.api import router
from app.core.exceptions import register_error_handlers


def create_app():
    app = FastAPI()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=['*'],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"]
    )
    app = register_error_handlers(app)
    app.include_router(router)
    return app


app = create_app()


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=5007)
