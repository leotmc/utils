import logging
import numpy as np
import os
import re
import typing
from typing import Any, Dict, List, Optional, Text

from app.nlu.featurizers import Featurizer
from app.nlu.training_data.message import Message
import app.nlu.utils.io
from app.nlu.constants import (
    MESSAGE_TOKENS_NAMES,
    MESSAGE_TEXT_ATTRIBUTE,
    MESSAGE_VECTOR_FEATURE_NAMES,
)

logger = logging.getLogger(__name__)

if typing.TYPE_CHECKING:
    from app.nlu.model import Metadata


class RegexFeaturizer(Featurizer):
    provides = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    requires = [MESSAGE_TOKENS_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns: Optional[List[Dict[Text, Text]]] = None,
    ):

        super(RegexFeaturizer, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def process(self, message: Message, **kwargs: Any) -> None:

        updated = self._text_features_with_regex(message)
        message.set(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE], updated)

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["RegexFeaturizer"] = None,
            **kwargs: Any
    ) -> "RegexFeaturizer":
        component_model_dir = os.path.join(model_dir, meta['name'])
        pattern_file = os.path.join(component_model_dir, meta["pattern_file"])
        if os.path.exists(pattern_file):
            known_patterns = app.nlu.utils.io.read_json_file(pattern_file)
            return RegexFeaturizer(meta, known_patterns=known_patterns)
        else:
            return RegexFeaturizer(meta)

    def _text_features_with_regex(self, message):
        if self.known_patterns:
            extras = self.features_for_patterns(message)
            return self._combine_with_existing_features(message, extras)
        else:
            return message.get(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE])

    def features_for_patterns(self, message):
        """Checks which known patterns match the message.
        Given a sentence, returns a vector of {1,0} values indicating which
        regexes did match. Furthermore, if the
        message is tokenized, the function will mark all tokens with a dict
        relating the name of the regex to whether it was matched."""

        found_patterns = []
        for exp in self.known_patterns:
            matches = re.finditer(exp["pattern"], message.text)
            matches = list(matches)
            found_patterns.append(False)
            for token_index, t in enumerate(
                    message.get(MESSAGE_TOKENS_NAMES[MESSAGE_TEXT_ATTRIBUTE], [])
            ):
                patterns = t.get("pattern", default={})
                patterns[exp["name"]] = False

                for match in matches:
                    if t.offset < match.end() and t.end > match.start():
                        patterns[exp["name"]] = True
                        found_patterns[-1] = True

                t.set("pattern", patterns)

        return np.array(found_patterns).astype(float)
