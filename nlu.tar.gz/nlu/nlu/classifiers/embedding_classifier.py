import os
import logging
import numpy as np
import tensorflow as tf
from tensorflow import keras
from typing import Optional, Dict, Text, Any, List
from nlu.classifiers import IntentClassifier
from nlu.training_data.data import TrainingData
from nlu.training_data.message import Message
from nlu.utils.util import write_json_to_file, read_json_file
from nlu.nlu_config import RasaNLUModelConfig
from nlu.model import Metadata


logger = logging.getLogger(__name__)


class EmbeddingClassifier(IntentClassifier):

    defaults = {
        "hidden_size": 128,
        "num_epochs": 20,
        "validation_split": 0.2,
        "early_stopping_patience": 5,
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ["tensorflow"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            classifier: Optional[tf.keras.models.Sequential] = None,
            label2intent: Optional[Dict[Text, Any]] = None
    ):
        super(EmbeddingClassifier, self).__init__(component_config)
        self.classifier = classifier
        self.label2intent = label2intent

    def train(
            self, training_data: TrainingData, config: RasaNLUModelConfig, **kwargs: Any
    ) -> None:
        intent_dict = self._create_intent_dict(training_data)
        self.label2intent = {label: intent for intent, label in intent_dict.items()}
        if len(intent_dict) < 2:
            logger.error("Can not train an intent classifier. "
                         "Need at least 2 different classes. "
                         "Skipping training of intent classifier.")
            return
        X, y = self._prepare_training_data(training_data, intent_dict)
        if self.classifier is None:
            self.classifier = self._create_classifier(X.shape[-1], len(intent_dict))
        self.classifier.fit(
            X,
            y,
            epochs=self.component_config["num_epochs"],
            validation_split=self.component_config["validation_split"],
            callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=self.component_config["early_stopping_patience"])]
        )

    def process(self, message: Message, **kwargs: Any) -> None:
        """Return the most likely intent and its probability for a message."""
        if not self.classifier:
            # component is either not trained or didn't
            # receive enough training data
            intent = None
            intent_ranking = []
        else:
            X = message.get("text_features").reshape(1, -1)
            probabilities = self.classifier.predict(X)
            probabilities = probabilities.flatten()
            sorted_indices = np.argsort(-probabilities).tolist()
            intent = {
                "name": self.label2intent[sorted_indices[0]],
                "confidence": float(probabilities[sorted_indices[0]]),
                "recognizer": self.name
            }
            intent_ranking = [
                {
                    "name": self.label2intent[label],
                    "confidence": float(probabilities[label])
                } for label in sorted_indices[:self.LABEL_RANKING_LENGTH]
            ]
        recognized_intent = message.get('intent')
        if intent['name'] == recognized_intent['name'] and intent['confidence'] < recognized_intent['confidence']:
            return
        message.set("intent", intent, add_to_output=True)
        message.set("intent_ranking", intent_ranking, add_to_output=True)

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory."""
        tf_model_file = os.path.join(model_dir, f'{file_name}.h5')
        label2intent_file = os.path.join(model_dir, file_name + "_label2intent.json")
        tf.keras.models.save_model(self.classifier, tf_model_file)
        write_json_to_file(label2intent_file, self.label2intent)
        return {"tf_model_file": tf_model_file, "label2intent_file": label2intent_file}

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["EmbeddingClassifier"] = None,
            **kwargs: Any
    ):
        tf_model_dir = meta.get("tf_model_dir")
        if not os.path.isdir(tf_model_dir):
            classifier = None
        else:
            classifier = tf.keras.models.load_model(tf_model_dir)
        if not os.path.exists(meta.get("label2intent_file")):
            label2intent = None
        else:
            label2intent = read_json_file(meta["label2intent_file"])
            label2intent = {int(key): value for key, value in label2intent.items()}
        return cls(meta, classifier, label2intent)

    def _prepare_training_data(self, training_data: TrainingData, intent_dict: Dict[Text, Any]):
        features = np.stack([e.get("text_features") for e in training_data.intent_examples])
        targets = np.array([intent_dict[e.get("intent")] for e in training_data.intent_examples])
        return features, targets

    def _create_intent_dict(self, training_data: TrainingData):
        """Create intent dictionary."""
        distinct_intents = set([e.get("intent") for e in training_data.intent_examples])
        return {intent: idx for idx, intent in enumerate(distinct_intents)}

    def _create_classifier(self, feature_dim, num_labels):

        model = keras.models.Sequential()
        model.add(keras.layers.Dense(self.component_config["hidden_size"], activation="relu", input_shape=[feature_dim, ]))
        model.add(keras.layers.Dense(num_labels, activation="softmax"))
        model.compile(
            optimizer="adam",
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"]
        )
        model.summary()
        return model
