import os
import typing
import numpy as np
from typing import Any, Text, Optional, Dict
from app.nlu.training_data.message import Message
from app.nlu.utils import util
from app.nlu.utils.trie import search_by_trie
from app.nlu.featurizers import Featurizer
from app.nlu.constants import (
    MESSAGE_TEXT_ATTRIBUTE,
    MESSAGE_VECTOR_FEATURE_NAMES
)

if typing.TYPE_CHECKING:
    from app.nlu.model import Metadata
    from dawg import IntDAWG


class LookupTableFeaturizer(Featurizer):

    provides = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            tries: Optional[Dict[Text, "IntDAWG"]] = None,
    ) -> None:
        super(LookupTableFeaturizer, self).__init__(component_config)
        self.tries = tries if tries else dict()

    def process(self, message: Message, **kwargs: Any):
        updated = self._text_features_with_lookup_table(message)
        message.set(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE], updated)

    def _text_features_with_lookup_table(self, message):
        if self.tries:
            extras = self.features_for_lookup_table(message)
            return self._combine_with_existing_features(message, extras)
        else:
            return message.get(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE])

    def features_for_lookup_table(self, message):
        found_patterns = []
        for intent, trie in self.tries.items():
            hits = search_by_trie(message.text, trie)
            if hits:
                found_patterns.append(True)
            else:
                found_patterns.append(False)
        return np.array(found_patterns).astype(float)

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["LookupTableFeaturizer"] = None,
            **kwargs: Any
    ) -> "LookupTableFeaturizer":
        component_model_dir = os.path.join(model_dir, meta['name'])
        trie_file = os.path.join(component_model_dir, meta['trie_file'])
        tries = util.json_unpickle(trie_file)
        return LookupTableFeaturizer(meta, tries=tries)
