import logging
import os

from typing import Optional, Text

import nlu.utils.io as io_utils
import re

from nlu.training_data.data import TrainingData
from nlu.training_data.reader import TrainingDataReader

logger = logging.getLogger(__name__)


# looks for pattern like:
# ##
# * intent/response_key
#   - response_text
_nlg_markdown_marker_regex = re.compile(r"##\s*.*\n\*.*\/.*\n\s*\t*\-.*")


def load_data(resource_name: Text) -> "TrainingData":
    """Load training data from disk.
    Merges them if loaded from disk and multiple files are found."""

    if not os.path.exists(resource_name):
        raise ValueError("File '{}' does not exist.".format(resource_name))

    files = io_utils.list_files(resource_name)
    data_sets = [_load(f) for f in files]
    data_sets = [ds for ds in data_sets if ds]
    if len(data_sets) == 0:
        training_data = TrainingData()
    elif len(data_sets) == 1:
        training_data = data_sets[0]
    else:
        training_data = data_sets[0].merge(*data_sets[1:])

    return training_data


def _load(filename: Text) -> Optional["TrainingData"]:
    """Loads a single training data file from disk."""
    return TrainingDataReader().read(filename)
