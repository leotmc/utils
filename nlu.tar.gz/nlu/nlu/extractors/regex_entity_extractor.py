import os
import re
from typing import Optional, Text, Dict, List, Any
from nlu.extractors import EntityExtractor
from nlu.utils.util import write_json_to_file, read_json_file
from nlu.training_data.data import TrainingData
from nlu.training_data.message import Message
from nlu.model import Metadata
from nlu.nlu_config import RasaNLUModelConfig


class RegexEntityExtractor(EntityExtractor):

    provides = ["entities"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns=None
    ):
        super(RegexEntityExtractor, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def train(self, training_data: TrainingData, config: RasaNLUModelConfig, **kwargs: Any):
        self.known_patterns = training_data.entity_regexs

    def process(self, message: Message, **kwargs: Any) -> None:
        extracted = self.add_extractor_name(self.extract_entities(message))
        message.set(
            "entities",
            message.get("entities", []) + extracted,
            add_to_output=True
        )

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
        Return the metadata necessary to load the model again."""
        file_name = file_name + ".pkl"
        regex_file = os.path.join(model_dir, file_name)
        write_json_to_file(regex_file, self.known_patterns, indent=4)
        return {"file": file_name}

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Text = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["RegexEntityExtractor"] = None,
            **kwargs: Any,
    ) -> "RegexEntityExtractor":
        file_name = meta.get("file")
        regex_file = os.path.join(model_dir, file_name)
        if os.path.exists(regex_file):
            known_patterns = read_json_file(regex_file)
            return RegexEntityExtractor(meta, known_patterns)
        else:
            return RegexEntityExtractor(meta)

    def extract_entities(self, message: Message) -> List[Dict[Text, Any]]:
        return self.entities_for_patterns(message)

    def entities_for_patterns(self, message: Message) -> List[Dict[Text, Any]]:
        entities = []
        for exp in self.known_patterns:
            matches = re.finditer(exp["pattern"], message.text)
            matches = list(matches)
            for match in matches:
                entities.append({
                    "start": match.start(),
                    "end": match.end(),
                    "value": match.group(),
                    "entity": exp["name"],
                    "confidence": 1.0
                })
        return entities

