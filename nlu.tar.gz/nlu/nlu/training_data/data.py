import logging
import warnings
import nlu.utils.common as rasa_utils
from collections import Counter, defaultdict
from copy import deepcopy
from typing import Any, Dict, List, Optional, Set, Text

from nlu.training_data.message import Message
from nlu.utils.util import list_to_str, get_text_hash, json_to_string
from nlu.training_data.util import check_duplicate_synonym

DEFAULT_TRAINING_DATA_OUTPUT_PATH = "training_data.json"

logger = logging.getLogger(__name__)


class TrainingData(object):
    """Holds loaded intent and entity training data."""

    # Validation will ensure and warn if these lower limits are not met
    MIN_EXAMPLES_PER_INTENT = 2
    MIN_EXAMPLES_PER_ENTITY = 2

    def __init__(
            self,
            training_examples: Optional[List[Message]] = None,
            entity_synonyms: Optional[Dict[Text, Text]] = None,
            intent_feature_regexs: Optional[List[Dict[Text, Text]]] = None,
            intent_classification_regexs: Optional[List[Dict[Text, Text]]] = None,
            intent_feature_lookup_tables: Optional[List[Dict[Text, Text]]] = None,
            intent_classification_lookup_tables: Optional[List[Dict[Text, Text]]] = None,
            entity_regexs: Optional[List[Dict[Text, Text]]] = None,
            entity_lookup_tables: Optional[List[Dict[Text, Text]]] = None,
    ) -> None:

        if training_examples:
            self.training_examples = self.sanitize_examples(training_examples)
        else:
            self.training_examples = []
        self.entity_synonyms = entity_synonyms if entity_synonyms else {}
        self.intent_feature_regexs = intent_feature_regexs if intent_feature_regexs else []
        self.intent_classification_regexs = intent_classification_regexs if intent_classification_regexs else []
        self.intent_feature_lookup_tables = intent_feature_lookup_tables if intent_feature_lookup_tables else []
        self.intent_classification_lookup_tables = intent_classification_lookup_tables if intent_classification_lookup_tables else []
        self.entity_regexs = entity_regexs if entity_regexs else []
        self.entity_lookup_tables = entity_lookup_tables if entity_lookup_tables else []

    def merge(self, *others: "TrainingData") -> "TrainingData":
        """Return merged instance of this data with other training data."""

        training_examples = deepcopy(self.training_examples)
        entity_synonyms = self.entity_synonyms.copy()
        intent_feature_regexs = deepcopy(self.intent_feature_regexs)
        intent_feature_lookup_tables = deepcopy(self.intent_feature_lookup_tables)
        intent_classification_regexs = deepcopy(self.intent_classification_regexs)
        intent_classification_lookup_tables = deepcopy(self.intent_classification_lookup_tables)
        entity_regexs = deepcopy(self.entity_regexs)
        entity_lookup_tables = deepcopy(self.entity_lookup_tables)
        others = [other for other in others if other]

        for o in others:
            training_examples.extend(deepcopy(o.training_examples))
            intent_feature_regexs.extend(deepcopy(o.intent_feature_regexs))
            intent_feature_lookup_tables.extend(deepcopy(o.intent_feature_lookup_tables))
            intent_classification_regexs.extend(deepcopy(o.intent_classification_regexs))
            intent_classification_lookup_tables.extend(deepcopy(o.intent_classification_lookup_tables))
            entity_regexs.extend(deepcopy(o.entity_regexs))
            entity_lookup_tables.extend(deepcopy(o.entity_lookup_tables))
            for text, syn in o.entity_synonyms.items():
                check_duplicate_synonym(
                    entity_synonyms, text, syn, "merging training data"
                )

            entity_synonyms.update(o.entity_synonyms)

        return TrainingData(
            training_examples,
            entity_synonyms,
            intent_feature_regexs,
            intent_classification_regexs,
            intent_feature_lookup_tables,
            intent_classification_lookup_tables,
            entity_regexs,
            entity_lookup_tables
        )

    @staticmethod
    def sanitize_examples(examples: List[Message]) -> List[Message]:
        """Makes sure the training data is clean.
        removes trailing whitespaces from intent annotations."""

        for ex in examples:
            if ex.get("intent"):
                ex.set("intent", ex.get("intent").strip())
            # if ex.get("response"):
            #     ex.set("response", ex.get("response").strip())
        return examples

    @rasa_utils.lazy_property
    def intent_examples(self) -> List[Message]:
        return [ex for ex in self.training_examples if ex.get("intent")]

    @rasa_utils.lazy_property
    def entity_examples(self) -> List[Message]:
        return [ex for ex in self.training_examples if ex.get("entities")]

    @rasa_utils.lazy_property
    def intents(self) -> Set[Text]:
        """Returns the set of intents in the training data."""
        return set([ex.get("intent") for ex in self.training_examples]) - {None}

    @rasa_utils.lazy_property
    def examples_per_intent(self) -> Dict[Text, int]:
        """Calculates the number of examples per intent."""
        intents = [ex.get("intent") for ex in self.training_examples]
        return dict(Counter(intents))

    @rasa_utils.lazy_property
    def entities(self) -> Set[Text]:
        """Returns the set of entity types in the training data."""
        entity_types = [e.get("entity") for e in self.sorted_entities()]
        return set(entity_types)

    @rasa_utils.lazy_property
    def examples_per_entity(self) -> Dict[Text, int]:
        """Calculates the number of examples per entity."""
        entity_types = [e.get("entity") for e in self.sorted_entities()]
        return dict(Counter(entity_types))

    def __hash__(self):
        stringified = self.as_json(sort_keys=True)
        text_hash = get_text_hash(stringified)
        return int(text_hash, 16)

    def as_json(self, sort_keys=True):
        js_entity_synonyms = defaultdict(list)
        for k, v in self.entity_synonyms.items():
            if k != v:
                js_entity_synonyms[v].append(k)

        formatted_synonyms = [
            {"value": value, "synonyms": syns}
            for value, syns in js_entity_synonyms.items()
        ]

        formatted_examples = [
            example.as_dict_nlu() for example in self.training_examples
        ]

        return json_to_string(
            {
                "nlu_data": {
                    "common_examples": formatted_examples,
                    "entity_synonyms": formatted_synonyms,
                    "intent_feature_regexs": self.intent_feature_regexs,
                    "intent_classification_regexs": self.intent_classification_regexs,
                    "intent_feature_lookup_tables": self.intent_feature_lookup_tables,
                    "intent_classification_lookup_tables": self.intent_classification_lookup_tables,
                    "entity_regexs": self.entity_regexs,
                    "entity_lookup_tables": self.entity_lookup_tables
                }
            }, sort_keys=sort_keys
        )

    def sorted_entities(self) -> List[Any]:
        """Extract all entities from examples and sorts them by entity type."""

        entity_examples = [
            entity for ex in self.entity_examples for entity in ex.get("entities")
        ]
        return sorted(entity_examples, key=lambda e: e["entity"])

    def sorted_intent_examples(self) -> List[Message]:
        """Sorts the intent examples by the name of the intent and then response"""

        return sorted(
            self.intent_examples, key=lambda e: (e.get("intent"), e.get("response"))
        )

    def validate(self) -> None:
        """Ensures that the loaded training data is valid.
        Checks that the data has a minimum of certain training examples."""

        logger.debug("Validating training data...")
        if "" in self.intents:
            warnings.warn(
                "Found empty intent, please check your "
                "training data. This may result in wrong "
                "intent predictions."
            )

        # emit warnings for intents with only a few training samples
        for intent, count in self.examples_per_intent.items():
            if count < self.MIN_EXAMPLES_PER_INTENT:
                warnings.warn(
                    "Intent '{}' has only {} training examples! "
                    "Minimum is {}, training may fail.".format(
                        intent, count, self.MIN_EXAMPLES_PER_INTENT
                    )
                )

        # emit warnings for entities with only a few training samples
        for entity_type, count in self.examples_per_entity.items():
            if count < self.MIN_EXAMPLES_PER_ENTITY:
                warnings.warn(
                    "Entity '{}' has only {} training examples! "
                    "minimum is {}, training may fail."
                    "".format(entity_type, count, self.MIN_EXAMPLES_PER_ENTITY)
                )

    def print_stats(self) -> None:
        logger.info(
            "Training data stats: \n"
            + "\t- intent examples: {} ({} distinct intents)\n".format(
                len(self.intent_examples), len(self.intents)
            )
            + "\t- Found intents: {}\n".format(list_to_str(self.intents))
            + "\t- entity examples: {} ({} distinct entities)\n".format(
                len(self.entity_examples), len(self.entities)
            )
            + "\t- found entities: {}\n".format(list_to_str(self.entities))
        )