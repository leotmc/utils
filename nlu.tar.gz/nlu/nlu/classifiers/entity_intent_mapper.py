from typing import Optional, Dict, Text, Any
from nlu.training_data.message import Message
from nlu.model import Metadata
from nlu.classifiers import IntentClassifier


class EntityIntentMapper(IntentClassifier):

    defaults = {
        'entity2intent': dict(),
        'entity_confidence_threshold': 0.75,
        'intent_confidence_threshold': 0.75
    }

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None
    ):
        super(EntityIntentMapper, self).__init__(component_config)

    def process(self, message: Message, **kwargs: Any):
        entity2intent = self.component_config['entity2intent']
        if not entity2intent or not message.get('entities'):
            return
        if message.get('intent') and message.get('intent')['confidence'] >= self.component_config['intent_confidence_threshold']:
            return
        extracted_entities = message.get('entities')
        for entity, intent in self.component_config['entity2intent'].items():
            for extracted_entity in extracted_entities:
                if entity == extracted_entity['entity'] and extracted_entity['confidence'] >= self.component_config['entity_confidence_threshold']:
                    mapped_intent = {'name': intent, 'confidence': extracted_entity['confidence'], "recognizer": self.name}
                    message.set('intent', mapped_intent, add_to_output=True)
                    message.set('intent_ranking', [])

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Text = None,
            model_metadata: Metadata = None,
            cached_component: Optional["EntityIntentMapper"] = None,
            **kwargs: Any
    ):
        return cls(meta)
