import os
import typing
from typing import Text, Any, List, Dict, Optional
from transformers import (
        AutoConfig,
        AutoTokenizer,
        AutoModelForSequenceClassification,
        TrainingArguments,
        Trainer
    )
from datasets import load_dataset
from nlu.classifiers import IntentClassifier


if typing.TYPE_CHECKING:
    from nlu.training_data.data import TrainingData
    from nlu.nlu_config import NLUModelConfig


class BertClassifier(IntentClassifier):

    """Classify intent with BERT."""

    provides = ["intent", "intent_ranking"]

    requires = []

    defaults = {
        "model_args": None,
        "training_args": None,
        "data_args": None
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ["transformers"]

    def __init__(
            self,
            component_config: Dict[Text, Any] = None,
            model: "AutoModelForSequenceClassification" = None,
            tokenizer: "AutoTokenizer" = None,
            config: "AutoConfig" = None,
    ):
        super(BertClassifier, self).__init__(component_config)
        self.config = AutoConfig.from_pretrained(component_config["pretrained_model_dir"]) if config is None else config
        self.tokenizer = AutoTokenizer.from_pretrained(component_config["pretrained_model_dir"]) if tokenizer is None else tokenizer
        self.model = AutoModelForSequenceClassification.from_pretrained(component_config["pretrained_model_dir"]) if model is None else model
        self.model_args = self.component_config.get("model_args", self.defaults["model_args"])
        self.training_args = self.component_config.get("training_args", self.defaults["training_args"])
        self.data_args = self.component_config.get("data_args", self.defaults["data_args"])
        self.trainer = Trainer(
            args=self.training_args,
            model=self.model,
            tokenizer=self.tokenizer
        )

    def train(
            self,
            training_data: TrainingData,
            config: NLUModelConfig,
            **kwargs: Any
    ) -> None:
        pass

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        self.trainer.save_model(model_dir)
        return {}
