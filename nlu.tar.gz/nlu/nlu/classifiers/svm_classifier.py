import os
import logging
import numpy as np
from typing import Dict, Text, Any, Optional, List, Tuple
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from nlu.classifiers import IntentClassifier
from nlu.training_data.data import TrainingData
from nlu.training_data.message import Message
from nlu.model import Metadata
from nlu.nlu_config import RasaNLUModelConfig
from nlu.utils.util import json_pickle, json_unpickle
from nlu.constants import (
    MESSAGE_VECTOR_FEATURE_NAMES,
    MESSAGE_TEXT_ATTRIBUTE
)

logger = logging.getLogger(__name__)


class SVMClassifier(IntentClassifier):
    """Intent classifier using the sklearn framework"""

    provides = ["intent", "intent_ranking"]

    requires = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    defaults = {
        # C parameter of the svm - cross validation will select the best value
        "C": [1, 2, 5, 10, 20, 100],
        # gamma parameter of the svm
        "gamma": [0.1],
        # the kernels to use for the svm training - cross validation will
        # decide which one of them performs best
        "kernels": ["linear"],
        # We try to find a good number of cross folds to use during
        # intent training, this specifies the max number of folds
        "max_cross_validation_folds": 5,
        # Scoring function used for evaluating the hyper parameters
        # This can be a name or a function (cfr GridSearchCV doc for more info)
        "scoring_function": "f1_weighted",
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ["sklearn"]

    def __init__(
            self,
            component_config: Dict[Text, Any] = None,
            classifier: "GridSearchCV" = None,
            label_encoder: Optional["LabelEncoder"] = None,
    ):
        """Construct a new intent classifier using the sklearn framework."""
        super(SVMClassifier, self).__init__(component_config)
        if label_encoder is not None:
            self.label_encoder = label_encoder
        else:
            self.label_encoder = LabelEncoder()
        self.classifier = classifier

    def train(
            self, training_data: TrainingData, config: RasaNLUModelConfig, **kwargs: Any
    ) -> None:
        """Train the intent classifier on a data set."""
        num_threads = kwargs.get("num_threads", 1)
        labels = [e.get("intent") for e in training_data.intent_examples]
        if len(set(labels)) < 2:
            logger.warning(
                "Can not train an intent classifier. "
                "Need at least 2 different classes. "
                "Skipping training of intent classifier."
            )
        else:
            y = self.transform_labels_str2num(labels)
            X = np.stack([e.get("text_features") for e in training_data.intent_examples])
            self.classifier = self._create_classifier(num_threads, y)
            self.classifier.fit(X, y)

    def process(self, message: Message, **kwargs: Any) -> None:
        """Return the most likely intent and its probability for a message."""
        if not self.classifier:
            # component is either not trained or didn't
            # receive enough training data
            intent = None
            intent_ranking = []
        else:
            X = message.get("text_features").reshape(1, -1)
            intent_ids, probabilities = self.predict(X)
            intents = self.transform_labels_num2str(np.ravel(intent_ids))
            # `predict` returns a matrix as it is supposed
            # to work for multiple examples as well, hence we need to flatten
            probabilities = probabilities.flatten()

            if intents.size > 0 and probabilities.size > 0:
                ranking = list(zip(list(intents), list(probabilities)))[:self.LABEL_RANKING_LENGTH]
                intent = {
                    "name": intents[0],
                    "confidence": probabilities[0],
                    "recognizer": self.name
                }
                intent_ranking = [{"name": intent_name, "confidence": score} for intent_name, score in ranking]
            else:
                intent = {"name": None, "confidence": 0.0, "recognizer": self.name}
                intent_ranking = []
        recognized_intent = message.get('intent')
        if intent['name'] == recognized_intent['name'] and intent['confidence'] < recognized_intent['confidence']:
            return
        message.set("intent", intent, add_to_output=True)
        message.set("intent_ranking", intent_ranking, add_to_output=True)

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory."""
        classifier_file_name = file_name + "_classifier.pkl"
        encoder_file_name = file_name + "_encoder.pkl"
        if self.classifier and self.label_encoder:
            json_pickle(os.path.join(model_dir, encoder_file_name), self.label_encoder.classes_)
            json_pickle(os.path.join(model_dir, classifier_file_name), self.classifier.best_estimator_)
        return {"classifier": classifier_file_name, "encoder": encoder_file_name}

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cache_component: Optional["SVMClassifier"] = None,
            **kwargs: Any
    ):
        classifier_file = os.path.join(model_dir, meta.get("classifier"))
        encoder_file = os.path.join(model_dir, meta.get("encoder"))
        if os.path.exists(classifier_file):
            classifier = json_unpickle(classifier_file)
            classes = json_unpickle(encoder_file)
            encoder = LabelEncoder()
            encoder.classes_ = classes
            return cls(meta, classifier, encoder)
        else:
            return cls(meta)

    def predict(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Given a bow vector of an input text, predict most probable label.
        Return only the most likely label.
        :param X: bow of input text
        :return: tuple of first, the most probable label and second,
                 its probability."""

        pred_result = self.predict_prob(X)
        # sort the probabilities retrieving the indices of
        # the elements in sorted order
        sorted_indices = np.fliplr(np.argsort(pred_result, axis=1))
        return sorted_indices, pred_result[:, sorted_indices]

    def predict_prob(self, X: np.ndarray) -> np.ndarray:
        """Given a bow vector of an input text, predict the intent label.
        Return probabilities for all labels.
        :param X: bow of input text
        :return: vector of probabilities containing one entry for each label"""
        return self.classifier.predict_proba(X)

    def transform_labels_str2num(self, labels: List[Text]) -> np.ndarray:
        """Transforms a list of strings into numeric label representation.
        :param labels: List of labels to convert to numeric representation"""
        return self.label_encoder.fit_transform(labels)

    def transform_labels_num2str(self, y: np.ndarray) -> np.ndarray:
        """Transforms a list of strings into numeric label representation.
        :param y: List of labels to convert to numeric representation"""

        return self.label_encoder.inverse_transform(y)

    def _create_classifier(self, num_threads, y):
        C = self.component_config["C"]
        kernels = self.component_config["kernels"]
        gamma = self.component_config["gamma"]
        # dirty str fix because sklearn is expecting
        # str not instance of basestr...
        tuned_parameters = [{"C": C, "gamma": gamma, "kernel": [str(k) for k in kernels]}]
        # aim for 5 examples in each fold
        cv_splits = self._num_cv_splits(y)
        return GridSearchCV(
            SVC(C=1, probability=True, class_weight="balanced"),
            param_grid=tuned_parameters,
            n_jobs=num_threads,
            cv=cv_splits,
            scoring=self.component_config["scoring_function"],
            verbose=1,
        )

    def _num_cv_splits(self, y):
        folds = self.component_config["max_cross_validation_folds"]
        return max(2, min(folds, np.min(np.bincount(y)) // 5))
