from collections import defaultdict, OrderedDict
from app.nlu.utils.re_util import (
    arabic_digit_pat,
    chinese_digit_pat,
    unit_pat
)
from app.nlu.utils.trie import search_by_trie
from app.constants import (
    NUMERIC_PROPERTIES,
    NODES,
    NODE_PROPERTIES,
    IntentMode,
    UNIT2RATIO,
    CHINESE2NUMBER,
    CHINESE2UNIT,
    PROPERTY_MAPPING
)
from app.logger import logger


class Formatter(object):

    def format_output(self, output, enumerable_entity_trie):
        output['entities'] = self._drop_invalid_enumerable_entities(output['entities'], enumerable_entity_trie)
        output['entities'] = self._drop_duplicate_entities(output['entities'])
        mode, node_from_intent = self._recognize_mode(output)
        slots = self._fill_slots(output, mode, node_from_intent)
        return {'intent': output['intent']['name'], 'confidence': output['intent']['confidence'], 'slots': slots, 'mode': mode}

    @staticmethod
    def _drop_invalid_enumerable_entities(entities, enumerable_entity_trie):
        """Drop invalid enumerable entities."""
        valid_entities = []
        for e in entities:
            if e['entity'] in enumerable_entity_trie:
                found_entities = search_by_trie(e['value'], enumerable_entity_trie[e['entity']])
                if not found_entities:
                    continue
                value, start, end = found_entities[0]
                e['start'] = e['start'] + start
                e['end'] = e['start'] + len(value) - 1
                e['value'] = value
                valid_entities.append(e)
            valid_entities.append(e)
        return valid_entities

    @staticmethod
    def _drop_duplicate_entities(entities):
        """Drop duplicate entities."""
        kept_entities = []
        sorted_entities = sorted(entities, key=lambda x: x['start'])
        prev_start, prev_end, prev_length, prev_confidence = 0, 0, 0, 0
        for i, e in enumerate(sorted_entities):
            cur_start, cur_end, cur_length, cur_confidence = e['start'], e['end'], e['end'] - e['start'], e['confidence']
            if i == 0:
                kept_entities.append(e)
                prev_start, prev_end, prev_length, prev_confidence = cur_start, cur_end, cur_length, cur_confidence
            elif cur_start == prev_start and cur_end == prev_end:
                if cur_confidence > prev_confidence:
                    kept_entities[-1] = e
                    prev_start, prev_end, prev_length, prev_confidence = cur_start, cur_end, cur_length, cur_confidence
            elif cur_start == prev_start:
                if cur_length > prev_length:
                    kept_entities[-1] = e
                    prev_start, prev_end, prev_length, prev_confidence = cur_start, cur_end, cur_length, cur_confidence
            elif cur_start > prev_end:    # Whether to skip overlapping entity ?
                kept_entities.append(e)
                prev_start, prev_end, prev_length, prev_confidence = cur_start, cur_end, cur_length, cur_confidence
        return kept_entities

    @staticmethod
    def _recognize_mode(output):
        """Recognize the mode.
        ST: Single-Topic
        MT: Multi-Topic
        """
        intent = output['intent']
        extracted_nodes = [e['entity'] for e in output['entities'] if e['entity'] in NODES]
        node_from_intent = intent['name'].split('_')[-1]
        extracted_nodes.append(node_from_intent)
        mode = IntentMode.MT.value if len(extracted_nodes) > 1 else IntentMode.ST.value
        return mode, node_from_intent

    def _fill_slots(self, output, mode, node_from_intent):
        if mode == IntentMode.ST.value:
            slots = self._fill_st_slots(output, node_from_intent)
        else:
            slots = self._fill_mt_slots(output, node_from_intent)
        slots = [slot for slot in slots]
        return slots

    def _fill_st_slots(self, output, node):
        """Format the output of single-topic intent."""
        constraints, numeric_conditions, countable_properties = [], OrderedDict(), []
        for entity in output['entities']:
            # 实体是节点名
            if entity['entity'] in NODES:
                constraints.append({
                    'property': 'name',
                    'description': '',
                    'conditions': [{'condition': '=', 'value': entity['value']}]
                })
            # 实体是节点属性
            elif entity['entity'] in NODE_PROPERTIES:
                if NODE_PROPERTIES[entity['entity']]['is_countable']:
                    countable_properties.append(entity['entity'])
                else:
                    constraints.append({
                        'property': entity['entity'],
                        'description': '',
                        'conditions': [{'condition': '=', 'value': entity['value']}]
                    })
            # 实体是数值类型属性(不隶属于某种类型的节点)
            elif entity['entity'] in NUMERIC_PROPERTIES:
                conditions = self._normalize_numeric_conditions(entity)
                if entity['entity'].startswith('distance'):
                    constraints.append({
                        'property': entity['entity'],
                        'description': '',
                        'conditions': conditions
                    })
                else:
                    numeric_conditions[entity['entity']] = conditions
            else:
                logger.warning(f'Unmatched entity: {entity["entity"]}')
        slots = [{'entity': node, 'constraints': constraints, 'is_main_entity': True}] \
            if constraints else [{'entity': node, 'constraints': [], 'is_main_entity': True}]
        # As one slot represent one topic(node), there are only one slot in ST mode
        slots[0]['constraints'].extend(self._fill_numeric_slot(countable_properties, numeric_conditions))
        return slots

    def _fill_mt_slots(self, output, node_from_intent):
        """Format the output of multi-topic intent."""
        node2constraints, node = defaultdict(list), None
        countable_properties, numeric_conditions = [], OrderedDict()
        for entity in output['entities']:
            # 实体是节点名
            if entity['entity'] in NODES:
                node = entity['entity']
                if not node2constraints[node]:
                    node2constraints[node] = []
                node2constraints[node].append({
                    'property': 'name',
                    'description': '',
                    'conditions': [{'condition': '=', 'value': entity['value']}]
                })
            # 实体是节点属性
            elif entity['entity'] in NODE_PROPERTIES:
                node = NODE_PROPERTIES[entity['entity']]['node']
                if not node2constraints[node]:
                    node2constraints[node] = []
                if NODE_PROPERTIES[entity['entity']]['is_countable']:
                    countable_properties.append(entity['entity'])
                else:
                    node2constraints[node].append({
                        'property': entity['entity'],
                        'description': '',
                        'conditions': [{'condition': '=', 'value': entity['value']}]
                    })
            # 实体是数值类型属性(不隶属于某种类型的节点)
            elif entity['entity'] in NUMERIC_PROPERTIES:
                conditions = self._normalize_numeric_conditions(entity)
                if node is not None and entity['entity'].startswith('distance'):
                    node2constraints[node].append({
                        'property': entity['entity'],
                        'description': '',
                        'conditions': conditions
                    })
                else:
                    numeric_conditions[entity['entity']] = conditions
            else:
                logger.warning(f'Unmatched entity: {entity["entity"]}')

        numeric_constraints = self._fill_numeric_slot(countable_properties, numeric_conditions)
        for constraints in numeric_constraints:
            node = NODE_PROPERTIES[constraints['property']]['node']
            node2constraints[node].append(constraints)
        slots = [{'entity': node, 'constraints':  constraints, 'is_main_entity': True if node == node_from_intent else False} for node, constraints in node2constraints.items()]
        return slots

    @staticmethod
    def _fill_numeric_slot(countable_properties, numeric_conditions):
        if not countable_properties and not numeric_conditions:
            return []
        matched_conditions, constraints = set(), []
        for countable_prop in countable_properties:
            for numeric_prop, conditions in numeric_conditions.items():
                if countable_prop in PROPERTY_MAPPING[numeric_prop]:
                    constraints.append({'property': countable_prop, 'description': '', 'conditions': conditions})
                    matched_conditions.add(numeric_prop)
                    break
        unmatched_conditions = {key: value for key, value in numeric_conditions.items() if key not in matched_conditions}
        for numeric_prop, conditions in unmatched_conditions.items():
            prop = PROPERTY_MAPPING[numeric_prop]
            constraints.append({'property': prop, 'description': '', 'conditions': conditions})
        return constraints

    def _normalize_numeric_conditions(self, entity):
        """Normalize numeric conditions."""
        arabic_digits = arabic_digit_pat.findall(entity['value'])
        chinese_digits = chinese_digit_pat.findall(arabic_digit_pat.sub('', entity['value']))
        digits = [self._normalize_arabic_digit(digit) for digit in arabic_digits] + [self._normalize_chinese_digit(digit) for digit in chinese_digits]
        units = unit_pat.findall(entity['value'])

        if not units:
            ratio1, ratio2 = 1.0, 1.0
        elif len(units) == 1:
            ratio1, ratio2 = UNIT2RATIO[units[0]], UNIT2RATIO[units[0]]
        else:
            ratio1, ratio2 = UNIT2RATIO[units[0]], UNIT2RATIO[units[1]]

        if not digits:
            if entity['entity'] == 'distance_less_than':    # 距离**最近
                return [{'condition': '<=', 'value': '-infinite'}]
            elif entity['entity'] == 'distance_more_than':  # 距离**最远
                return [{'condition': '>=', 'value': '+infinite'}]
            else:
                return []

        if 'between' in entity['entity']:
            if len(digits) != 2:
                return []
            return [{'condition': '>=', 'value': digits[0] * ratio1}, {'condition': '<=', 'value': digits[1] * ratio2}]
        elif 'more_than' in entity['entity']:
            return [{'condition': '>=', 'value': digits[0] * ratio1}]
        else:
            return [{'condition': '<=', 'value': digits[0] * ratio1}]

    @staticmethod
    def _normalize_arabic_digit(arabic_digit):
        if arabic_digit.endswith('万'):
            return float(arabic_digit[:-1]) * 10000.0
        elif arabic_digit.endswith('亿'):
            return float(arabic_digit[:-1]) * 100000000.0
        elif arabic_digit.endswith('万亿'):
            return float(arabic_digit[:-2]) * 1000000000000.0
        else:
            return float(arabic_digit)

    def _normalize_chinese_digit(self, chinese_digit):
        if len(chinese_digit) == 1:
            return CHINESE2NUMBER[chinese_digit]
        biggest_unit, number_for_unit = None, -1
        if chinese_digit.endswith('万亿'):
            biggest_unit = '万亿'
            number_for_unit = 1000000000000.0
        else:
            for c in chinese_digit:
                if c in CHINESE2UNIT and CHINESE2UNIT[c] > number_for_unit:
                    number_for_unit = CHINESE2UNIT[c]
                    biggest_unit = c
        if chinese_digit.endswith(biggest_unit):
            unit = number_for_unit
            chinese_digit = chinese_digit[:-2] if chinese_digit.endswith('万亿') else chinese_digit[:-1]
            segments = [chinese_digit[i: i + 2] for i in range(0, len(chinese_digit), 2)]
            segments = [s for s in segments if len(s) == 2]
            if len(chinese_digit) == 1:
                arabic_number = CHINESE2NUMBER[chinese_digit] * unit
            else:
                arabic_number = sum([CHINESE2NUMBER[s[0]] * CHINESE2UNIT[s[1]] for s in segments]) * unit
        else:
            index = chinese_digit.find(biggest_unit)
            arabic_number = self._normalize_chinese_digit(chinese_digit[:index + 1]) + self._normalize_chinese_digit(chinese_digit[index + 1:])
        return arabic_number


formatter = Formatter()
