"""This is a somewhat delicate package. It contains all registered components
and preconfigured templates.
Hence, it imports all of the components. To avoid cycles, no component should
import this in module scope."""

import logging
import typing
from typing import Any, Dict, List, Optional, Text, Type

from nlu.classifiers.lookup_table_classifier import LookupTableClassifier
from nlu.classifiers.regex_classifier import RegexClassifier
from nlu.classifiers.svm_classifier import SVMClassifier
from nlu.classifiers.embedding_classifier import EmbeddingClassifier
from nlu.classifiers.intent_corrector import IntentSimilarityCorrector
from nlu.classifiers.entity_intent_mapper import EntityIntentMapper
from nlu.extractors.crf_entity_extractor import CRFEntityExtractor
from nlu.extractors.entity_synonyms import EntitySynonymMapper
from nlu.extractors.lookup_table_entity_extractor import LookupTableEntityExtractor
from nlu.extractors.regex_entity_extractor import RegexEntityExtractor
# from nlu.extractors.bilstm_crf_extractor import BiLSTMCRFEntityExtractor
from nlu.featurizers.count_vectors_featurizer import CountVectorsFeaturizer
from nlu.featurizers.regex_featurizer import RegexFeaturizer
from nlu.featurizers.lookup_table_featurizer import LookupTableFeaturizer
# from nlu.featurizers.bert_featurizer import BertFeaturizer
from nlu.model import Metadata
from nlu.tokenizers.jieba_tokenizer import JiebaTokenizer
from nlu.tokenizers.whitespace_tokenizer import WhitespaceTokenizer
from nlu.utils.common import class_from_module_path

if typing.TYPE_CHECKING:
    from nlu.components import Component
    from nlu.nlu_config import NLUModelConfig

logger = logging.getLogger(__name__)

# Classes of all known components. If a new component should be added,
# its class name should be listed here.
component_classes = [
    # tokenizers
    WhitespaceTokenizer,
    JiebaTokenizer,
    # # extractors
    CRFEntityExtractor,
    EntitySynonymMapper,
    LookupTableEntityExtractor,
    RegexEntityExtractor,
    # BiLSTMCRFEntityExtractor,
    # featurizers
    RegexFeaturizer,
    LookupTableFeaturizer,
    CountVectorsFeaturizer,
    # BertFeaturizer,
    # # classifiers
    LookupTableClassifier,
    RegexClassifier,
    SVMClassifier,
    EmbeddingClassifier,
    IntentSimilarityCorrector,
    EntityIntentMapper
    # KeywordIntentClassifier,
    # EmbeddingIntentClassifier,
    # # selectors
    # ResponseSelector,
]

# Mapping from a components name to its class to allow name based lookup.
registered_components = {c.name: c for c in component_classes}


def get_component_class(component_name: Text) -> Type["Component"]:
    """Resolve component name to a registered components class."""
    return registered_components[component_name]


def create_component_by_config(
        component_config: Dict[Text, Any], config: "NLUModelConfig"
) -> Optional["Component"]:
    """Resolves a component and calls it's create method.
    Inits it based on a previously persisted model.
    """
    # try to get class name first, else create by name
    component_name = component_config.get("class", component_config["name"])
    component_class = get_component_class(component_name)
    return component_class.create(component_config, config)
