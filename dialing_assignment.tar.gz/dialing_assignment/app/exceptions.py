from fastapi import status
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from app.constants import SUPPORT_TASKS


class ServerInternalError(Exception):
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    description = 'Server internal error.'

    def __init__(self, description=None):
        if description is not None:
            self.description = description


class InvalidTask(Exception):

    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    description = f'Invalid task, you can choose one of the supported tasks: {SUPPORT_TASKS}'

    def __init__(self, description=None):
        if description is not None:
            self.description = description


def register_error_handlers(app: FastAPI):

    @app.exception_handler(InvalidTask)
    def handle_invalid_task(request: Request, e: InvalidTask):
        return JSONResponse(
            status_code=e.status_code,
            content={'message': e.description}
        )

    @app.exception_handler(ServerInternalError)
    def handle_server_internal_error(request: Request, e: ServerInternalError):
        return JSONResponse(
            status_code=e.status_code,
            content={'message': e.description}
        )
