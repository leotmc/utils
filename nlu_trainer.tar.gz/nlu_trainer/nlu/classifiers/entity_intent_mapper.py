from typing import Optional, Dict, Text, Any
from nlu.classifiers import IntentClassifier


class EntityIntentMapper(IntentClassifier):

    defaults = {
        'entity2intent': dict(),
        'entity_confidence_threshold': 0.75,
        'intent_confidence_threshold': 0.75
    }

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None
    ):
        super(EntityIntentMapper, self).__init__(component_config)
