from fastapi import APIRouter
from app.api.api_v1.endpoints import classification


router = APIRouter()
router.include_router(classification.router, prefix='/dialing-assignment')
