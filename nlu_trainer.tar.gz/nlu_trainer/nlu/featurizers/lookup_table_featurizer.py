import os
import typing
import numpy as np
from typing import Any, Text, Optional, Dict, List
from nlu.nlu_config import NLUModelConfig
from nlu.utils import util
from nlu.utils.trie import build_trie, search_by_trie
from nlu.training_data.data import TrainingData
from nlu.featurizers import Featurizer
from nlu.constants import (
    MESSAGE_TEXT_ATTRIBUTE,
    MESSAGE_VECTOR_FEATURE_NAMES
)

if typing.TYPE_CHECKING:
    from dawg import IntDAWG


class LookupTableFeaturizer(Featurizer):

    provides = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            trie_map: Optional[Dict[Text, "IntDAWG"]] = None,
    ) -> None:
        super(LookupTableFeaturizer, self).__init__(component_config)
        self.trie_map = trie_map if trie_map else dict()

    def train(
            self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any
    ) -> None:
        self._build_trie_map(training_data.intent_feature_lookup_tables)
        for example in training_data.training_examples:
            updated = self._text_features_with_lookup_table(example)
            example.set(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE], updated)

    def _text_features_with_lookup_table(self, message):
        if self.trie_map:
            extras = self.features_for_lookup_table(message)
            return self._combine_with_existing_features(message, extras)
        else:
            return message.get(MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE])

    def features_for_lookup_table(self, message):
        found_patterns = []
        for intent, trie in self.trie_map.items():
            hits = search_by_trie(message.text, trie)
            if hits:
                found_patterns.append(True)
            else:
                found_patterns.append(False)
        return np.array(found_patterns).astype(float)

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
        Return the metadata necessary to load the model again."""
        file_name = file_name + '.pkl'
        trie_map_file = os.path.join(model_dir, file_name)
        util.json_pickle(trie_map_file, self.trie_map)
        return {"file": file_name}

    def _build_trie_map(self, lookup_tables: List[Dict[Text, Any]]):
        for table in lookup_tables:
            name = table['name']
            elements = table['elements']
            trie = build_trie(elements)
            self.trie_map[name] = trie
