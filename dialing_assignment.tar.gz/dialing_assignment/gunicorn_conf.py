from multiprocessing import cpu_count


loglevel = 'debug'
pidfile = "logs/gunicorn.pid"
accesslog = "logs/access.log"
errorlog = "logs/debug.log"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'
daemon = False
workers = cpu_count() * 2 + 1
worker_class = 'uvicorn.workers.UvicornWorker'
bind = "0.0.0.0:5100"
# Workers silent for more than this many seconds are killed and restarted, Setting it to 0 has the effect of infinite
# timeouts by disabling timeouts for all workers entirely.
timeout = 0
