from app.nlu.model import Interpreter
from app.nlu.format import Formatter
from app.config import nlu_model_path
from app.constants import ENUMERABLE_PROPERTIES


class Parser(object):

    def __init__(self):
        self.interpreter = Interpreter.load(nlu_model_path)
        self.formatter = Formatter()

    def parse(self, query):
        output = self.interpreter.parse(query)
        enumerable_entity_trie = self._get_enumerable_entity_trie()
        output = self.formatter.format_output(output, enumerable_entity_trie)
        return output

    def _get_enumerable_entity_trie(self):
        for component in self.interpreter.pipeline:
            if component.name == 'LookupTableExtractor':
                return {key: value for key, value in component.tries.items() if
                        key in ENUMERABLE_PROPERTIES} if component.tries else None


parser = Parser()


if __name__ == '__main__':
    res = parser.parse('有哪些营业期限超过10年的建筑行业的公司')
