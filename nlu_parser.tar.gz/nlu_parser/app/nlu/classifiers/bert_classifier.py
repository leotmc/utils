import os
import json
import requests
import numpy as np
from scipy.special import softmax
from transformers import AutoTokenizer, BertTokenizer
from typing import Optional, Dict, Text, Any, List
from app.nlu.utils.io import read_json_file
from app.nlu.classifiers import IntentClassifier
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata
from app.config import (
    tf_serving_host,
    tf_serving_port,
    intent_classification_model_name
)


class BertClassifier(IntentClassifier):

    defaults = {
        'max_seq_length': 50,
        'serving_host': tf_serving_host,
        'serving_port': tf_serving_port,
        'model_name': intent_classification_model_name
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ['transformers', 'requests']

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            index2label: Optional[Dict[int, Any]] = None,
            tokenizer: Optional[BertTokenizer] = None
    ):
        super(BertClassifier, self).__init__(component_config)
        self.index2label = index2label
        self.tokenizer = tokenizer
        self.max_seq_length = self.component_config['max_seq_length']
        self.serving_url = f'http://{self.component_config["serving_host"]}:{self.component_config["serving_port"]}/v1/models/{self.component_config["model_name"]}:predict'

    def process(self, message: Message, **kwargs: Any) -> None:
        query = message.text
        tokenized_results = self.tokenizer([query], max_length=self.max_seq_length, truncation=True, padding='max_length')
        instances = []
        for input_id, token_type_id, attention_mask in zip(tokenized_results['input_ids'], tokenized_results['token_type_ids'], tokenized_results['attention_mask']):
            instances.append({'input_ids': input_id, 'token_type_ids': token_type_id, 'attention_mask': attention_mask})
        data = json.dumps({'signature_name': 'serving_default', 'instances': instances})
        response = requests.post(self.serving_url, data=data, headers={'content-type': 'application/json'})
        logits = json.loads(response.text)['predictions'][0]
        probabilities = softmax(logits)
        sorted_indices = np.argsort(-probabilities)
        label = self.index2label[sorted_indices[0]]
        intent = {"name": label, "confidence": float(probabilities[sorted_indices[0]]), "recognizer": self.name}
        intent_ranking = [
            {
                "name": self.index2label[index],
                "confidence": float(probabilities[index])
            } for index in sorted_indices[:self.LABEL_RANKING_LENGTH]]
        # 若通过其他classifier识别出的意图的confidence更高，则提前返回
        recognized_intent = message.get("intent")
        if recognized_intent and recognized_intent["confidence"] > intent["confidence"]:
            return
        message.set("intent", intent, add_to_output=True)
        message.set('intent_ranking', intent_ranking)

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["BertClassifier"] = None,
            **kwargs
    ):
        component_model_dir = os.path.join(model_dir, meta["name"])
        index_label_mapping_file = os.path.join(component_model_dir, meta["index_label_mapping_file"])
        pretrained_model_dir = os.path.join(component_model_dir, meta['pretrained_model'])
        tokenizer = AutoTokenizer.from_pretrained(pretrained_model_dir)
        index2label = read_json_file(index_label_mapping_file)
        index2label = {int(index): label for index, label in index2label.items()}
        return cls(meta, index2label, tokenizer)
