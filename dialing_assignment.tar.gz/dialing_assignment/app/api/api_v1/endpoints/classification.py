import traceback
from fastapi import APIRouter
from app.logger import logger
from app.schemas.query import Queries
from app.schemas.response import Predictions
from app.exceptions import ServerInternalError
from app.core.classifier import classifier
from app.constants import DEFAULT_RECOMMENDATION_SIZE


router = APIRouter()


@router.post('/classification', response_model=Predictions)
def classify(task: str, queries: Queries, size: int = DEFAULT_RECOMMENDATION_SIZE):
    try:
        queries = [q.dict() for q in queries.queries]
        res = classifier.classify(task, size, queries)
        return Predictions(**{'predictions': res})
    except:
        logger.error(traceback.format_exc())
        raise ServerInternalError
