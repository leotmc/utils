from pydantic import BaseModel
from typing import List, Text, Dict, Any, Optional


class Constraint(BaseModel):
    property: Text
    description: Text
    conditions: Optional[List[Dict[Text, Any]]] = []


class Slot(BaseModel):
    entity: Optional[Text] = None
    constraints: Optional[List[Constraint]] = []
    is_main_entity: bool


class ParsedResult(BaseModel):
    intent: Text
    confidence: float
    mode: Text
    slots: Optional[List[Slot]] = []
