from typing import Optional, Text, List
from pydantic import BaseModel


class Query(BaseModel):
    complaint: Text
    address: Optional[Text] = None


class Queries(BaseModel):
    queries: List[Query]
