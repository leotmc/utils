import re

# 352.5万
arabic_digit_pat = re.compile(r'\d*\.?\d+[万亿]?')
# 三百五十二亿
chinese_digit_pat = re.compile(r'[半一二两三四五六七八九十百千万亿]+')
unit_pat = re.compile(r'(天|周|星期|月|半年|年|米|里|公里|千米)')

