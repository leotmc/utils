import io
import json
import os
import re
import logging
from hashlib import md5
from typing import Any, Dict, List, Optional, Text
from app.nlu.constants import FINGERPRINT_NLU_DATA_KEY, FINGERPRINT_CONFIG_NLU_KEY, FINGERPRINT_FILE_PATH
from app.nlu.utils.io import read_json_file

# backwards compatibility 1.0.x
# noinspection PyUnresolvedReferences

logger = logging.getLogger(__name__)


def relative_normpath(f: Optional[Text], path: Text) -> Optional[Text]:
    """Return the path of file relative to `path`."""

    if f is not None:
        return os.path.normpath(os.path.relpath(f, path))
    else:
        return None


def list_to_str(l: List[Text], delim: Text = ", ", quote: Text = "'") -> Text:
    return delim.join([quote + e + quote for e in l])


def ordered(obj: Any) -> Any:
    if isinstance(obj, dict):
        return sorted((k, ordered(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return sorted(ordered(x) for x in obj)
    else:
        return obj


def module_path_from_object(o: Any) -> Text:
    """Returns the fully qualified class path of the instantiated object."""
    return o.__class__.__module__ + "." + o.__class__.__name__


def json_to_string(obj: Any, **kwargs: Any) -> Text:
    indent = kwargs.pop("indent", 2)
    ensure_ascii = kwargs.pop("ensure_ascii", False)
    return json.dumps(obj, indent=indent, ensure_ascii=ensure_ascii, **kwargs)


def write_json_to_file(filename: Text, obj: Any, **kwargs: Any) -> None:
    """Write an object as a json string to a file."""

    write_to_file(filename, json_to_string(obj, **kwargs))


def write_to_file(filename: Text, text: Text) -> None:
    """Write a text to a file."""

    with io.open(filename, "w", encoding="utf-8") as f:
        f.write(str(text))


def build_entity(
        start: int, end: int, value: Text, entity_type: Text, **kwargs: Dict[Text, Any]
) -> Dict[Text, Any]:
    """Builds a standard entity dictionary.
    Adds additional keyword parameters."""

    entity = {"start": start, "end": end, "value": value, "entity": entity_type}

    entity.update(kwargs)
    return entity


def is_model_dir(model_dir: Text) -> bool:
    """Checks if the given directory contains a model and can be safely removed.
    specifically checks if the directory has no subdirectories and
    if all files have an appropriate ending."""
    allowed_extensions = {".json", ".pkl", ".dat"}
    dir_tree = list(os.walk(model_dir))
    if len(dir_tree) != 1:
        return False
    model_dir, child_dirs, files = dir_tree[0]
    file_extenstions = [os.path.splitext(f)[1] for f in files]
    only_valid_files = all([ext in allowed_extensions for ext in file_extenstions])
    return only_valid_files


def is_url(resource_name: Text) -> bool:
    """Return True if string is an http, ftp, or file URL path.
    This implementation is the same as the one used by matplotlib"""

    URL_REGEX = re.compile(r"http://|https://|ftp://|file://|file:\\")
    return URL_REGEX.match(resource_name) is not None


def remove_model(model_dir: Text) -> bool:
    """Removes a model directory and all its content."""
    import shutil

    if is_model_dir(model_dir):
        shutil.rmtree(model_dir)
        return True
    else:
        raise ValueError(
            "Cannot remove {}, it seems it is not a model "
            "directory".format(model_dir)
        )


def json_unpickle(file_name: Text) -> Any:
    """Unpickle an object from file using json."""
    import jsonpickle.ext.numpy as jsonpickle_numpy
    import jsonpickle

    jsonpickle_numpy.register_handlers()

    with open(file_name, "r", encoding="utf-8") as f:
        return jsonpickle.loads(f.read())


def json_pickle(file_name: Text, obj: Any) -> None:
    """Pickle an object to a file using json."""
    import jsonpickle.ext.numpy as jsonpickle_numpy
    import jsonpickle

    jsonpickle_numpy.register_handlers()

    with open(file_name, "w", encoding="utf-8") as f:
        f.write(jsonpickle.dumps(obj))


def read_file(filename: Text) -> List:
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read().split('\n')


def model_fingerprint(nlu_config, training_data):
    return {
        FINGERPRINT_CONFIG_NLU_KEY: get_dict_hash(nlu_config),
        FINGERPRINT_NLU_DATA_KEY: hash(training_data)
    }


def fingerprint_from_path(model_path):
    """Loads a persisted fingerprint.

    Args:
        model_path: Path to directory containing the fingerprint.

    Returns:
        The fingerprint or an empty dict if no fingerprint was found.
    """
    if not model_path or not os.path.exists(model_path):
        return {}

    fingerprint_path = os.path.join(model_path, FINGERPRINT_FILE_PATH)

    if os.path.isfile(fingerprint_path):
        return read_json_file(fingerprint_path)
    else:
        return {}


def persist_fingerprint(output_path, fingerprint):
    """Persists a model fingerprint.

    Args:
        output_path: Directory in which the fingerprint should be saved.
        fingerprint: The fingerprint to be persisted.

    """
    path = os.path.join(output_path, FINGERPRINT_FILE_PATH)
    write_json_to_file(path, fingerprint)


def fingerprint_changed(fingerprint1, fingerprint2):
    """Checks whether the fingerprints of the model changed.

    Args:
        fingerprint1: A fingerprint.
        fingerprint2: Another fingerprint.

    Returns:
        `True` if the fingerprint for the model changed, else `False`.

    """

    relevant_keys = [
        FINGERPRINT_CONFIG_NLU_KEY,
        FINGERPRINT_NLU_DATA_KEY,
    ]

    for k in relevant_keys:
        if fingerprint1.get(k) != fingerprint2.get(k):
            logger.info("Data ({}) for model changed.".format(k))
            return True
    return False


def get_dict_hash(data: Dict, encoding: Text = 'utf-8') -> Text:
    return md5(json.dumps(data, sort_keys=True).encode(encoding)).hexdigest()


def get_text_hash(text: Text, encoding: Text = 'utf-8') -> Text:
    return md5(text.encode(encoding)).hexdigest()
