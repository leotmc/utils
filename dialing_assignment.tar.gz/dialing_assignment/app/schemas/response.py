from typing import Text, List
from pydantic import BaseModel


class Prediction(BaseModel):
    label: Text
    confidence: float


class Predictions(BaseModel):
    predictions: List[List[Prediction]]
