import os
from typing import Optional, Text, Dict, Any
from nlu.extractors import EntityExtractor
from nlu.utils.util import write_json_to_file
from nlu.training_data.data import TrainingData
from nlu.nlu_config import NLUModelConfig


class RegexEntityExtractor(EntityExtractor):

    provides = ["entities"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns=None
    ):
        super(RegexEntityExtractor, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def train(self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any):
        self.known_patterns = training_data.entity_regexs

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
        Return the metadata necessary to load the model again."""
        file_name = file_name + ".pkl"
        regex_file = os.path.join(model_dir, file_name)
        write_json_to_file(regex_file, self.known_patterns, indent=4)
        return {"file": file_name}
