from app.nlu.featurizers import Featurizer


class SimCSEFeaturizer(Featurizer):
    pass
