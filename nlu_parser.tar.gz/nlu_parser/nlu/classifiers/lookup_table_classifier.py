import os
import typing
from typing import Optional, Dict, Text, Any
from nlu.utils import util
from nlu.classifiers import IntentClassifier
from nlu.training_data.message import Message
from nlu.model import Metadata
from nlu.utils.trie import search_by_trie


if typing.TYPE_CHECKING:
    from dawg import IntDAWG


class LookupTableClassifier(IntentClassifier):

    provides = ["intent"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            trie_map: Optional[Dict[Text, "IntDAWG"]] = None,
    ):
        super(LookupTableClassifier, self).__init__(component_config)
        self.trie_map = trie_map if trie_map else dict()

    def process(self, message: Message, **kwargs: Any) -> None:
        for intent_name, trie in self.trie_map.items():
            hits = search_by_trie(message.text, trie)
            if hits:
                intent = {"name": intent_name, "confidence": 1.0, "recognizer": self.name}
                message.set("intent", intent, add_to_output=True)
                message.set('intent_ranking', [])

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["LookupTableClassifier"] = None,
            **kwargs: Any
    ):
        file_name = meta.get("file")
        trie_map_file = os.path.join(model_dir, file_name)
        trie_map = util.json_unpickle(trie_map_file)
        return LookupTableClassifier(meta, trie_map)
