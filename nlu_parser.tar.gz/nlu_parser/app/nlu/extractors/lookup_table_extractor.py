import os
import typing
import warnings
from typing import Optional, Dict, Text, Any, List
from app.nlu.extractors import EntityExtractor
from app.nlu.utils.util import json_unpickle
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata
from app.nlu.utils.trie import search_by_trie


if typing.TYPE_CHECKING:
    from dawg import IntDAWG


class LookupTableExtractor(EntityExtractor):
    
    provides = ["entities"]
    
    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            tries: Optional[Dict[Text, "IntDAWG"]] = None,
            
    ):
        super(LookupTableExtractor, self).__init__(component_config)
        self.tries = tries if tries else dict()
    
    def process(self, message: Message, **kwargs: Any) -> None:
        extracted = self.add_extractor_name(self.extract_entities(message))
        message.set(
            "entities",
            message.get("entities", []) + extracted,
            add_to_output=True
        )

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["LookupTableExtractor"] = None,
            **kwargs: Any,
    ) -> "LookupTableExtractor":
        component_model_dir = os.path.join(model_dir, meta['name'])
        trie_file = os.path.join(component_model_dir, meta['trie_file'])
        if os.path.exists(trie_file):
            tries = json_unpickle(trie_file)
            return cls(meta, tries)
        else:
            warnings.warn("Failed to load trie map file from '{}'".format(trie_file))
            return cls(meta)

    def extract_entities(self, message: Message) -> List[Dict[Text, Any]]:
        """Take a sentence and return entities in json format"""
        entities = []
        unique_entities = set()
        for slot, trie in self.tries.items():
            hits = search_by_trie(message.text, trie)
            hits = [h for h in hits if h not in unique_entities]
            unique_entities.update(hits)
            if not hits:
                continue
            value, start, end = hits[0]
            entities.append({
                "start": start,
                "end": end,
                "value": value,
                "entity": slot,
                "confidence": 1.0
            })
        return entities
