from typing import Text
from nlu.model import Interpreter
from config import nlu_model_path


def load_interpreter(
    model_path: Text,
):
    return Interpreter.load(model_path)


interpreter = load_interpreter(nlu_model_path)
