import os
import warnings
from typing import Optional, Dict, Text, Any
from nlu.utils.io import read_json_file
from nlu.extractors import EntityExtractor
from nlu.training_data.message import Message
from nlu.model import Metadata


class EntitySynonymMapper(EntityExtractor):

    provides = ["entities"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            synonyms: Optional[Dict[Text, Any]] = None,
    ) -> None:
        super(EntitySynonymMapper, self).__init__(component_config)
        self.synonyms = synonyms if synonyms else {}

    def process(
            self, message: Message, **kwargs: Any
    ):
        updated_entities = message.get("entities", [])[:]
        self.replace_synonyms(updated_entities)
        message.set("entities", updated_entities, add_to_output=True)

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["EntitySynonymMapper"] = None,
            **kwargs: Any
    ):
        file_name = meta.get("file")
        if not file_name:
            return cls(meta)
        entity_synonyms_file = os.path.join(model_dir, file_name)
        if os.path.exists(entity_synonyms_file):
            synonyms = read_json_file(entity_synonyms_file)
        else:
            synonyms = None
            warnings.warn("Failed to load synonyms file from '{}'".format(entity_synonyms_file))
        return cls(meta, synonyms)

    def replace_synonyms(self, entities):
        for entity in entities:
            # need to wrap in `str` to handle e.g. entity values of type int
            entity_value = str(entity["value"])
            if entity_value.lower() in self.synonyms:
                entity["value"] = self.synonyms[entity_value.lower()]
                self.add_processor_name(entity)
