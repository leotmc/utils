import re
import os
import logging
from typing import Dict, Text, Any, Optional, List
from sklearn.feature_extraction.text import CountVectorizer
from app.nlu.training_data.message import Message
from app.nlu.model import Metadata
from app.nlu.utils import util
from app.nlu.featurizers import Featurizer
from app.nlu.constants import (
    MESSAGE_VECTOR_FEATURE_NAMES,
    MESSAGE_ATTRIBUTES,
    MESSAGE_TEXT_ATTRIBUTE,
    MESSAGE_TOKENS_NAMES,
    MESSAGE_INTENT_ATTRIBUTE
)

logger = logging.getLogger(__name__)


class CountVectorsFeaturizer(Featurizer):

    provides = [MESSAGE_VECTOR_FEATURE_NAMES[attribute] for attribute in MESSAGE_ATTRIBUTES]

    requires = []

    defaults = {
        # whether to use a shared vocab
        "use_shared_vocab": False,
        # the parameters are taken from
        # sklearn's CountVectorizer
        # whether to use word or character n-grams
        # 'char_wb' creates character n-grams inside word boundaries
        # n-grams at the edges of words are padded with space.
        "analyzer": "word",  # use 'char' or 'char_wb' for character
        # regular expression for tokens
        # only used if analyzer == 'word'
        "token_pattern": r"(?u)\b\w\w+\b",
        # remove accents during the preprocessing step
        "strip_accents": None,  # {'ascii', 'unicode', None}
        # list of stop words
        "stop_words": None,  # string {'english'}, list, or None (default)
        # min document frequency of a word to add to vocabulary
        # float - the parameter represents a proportion of documents
        # integer - absolute counts
        "min_df": 1,  # float in range [0.0, 1.0] or int
        # max document frequency of a word to add to vocabulary
        # float - the parameter represents a proportion of documents
        # integer - absolute counts
        "max_df": 1.0,  # float in range [0.0, 1.0] or int
        # set range of ngrams to be extracted
        "min_ngram": 1,  # int
        "max_ngram": 1,  # int
        # limit vocabulary size
        "max_features": None,  # int or None
        # if convert all characters to lowercase
        "lowercase": True,  # bool
        # handling Out-Of-Vacabulary (OOV) words
        # will be converted to lowercase if lowercase is True
        "OOV_token": None,  # string or None
        "OOV_words": [],  # string or list of strings
    }

    def __init__(
            self,
            component_config: Dict[Text, Any] = None,
            vectorizers: Optional[Dict[Text, "CountVectorizer"]] = None
    ) -> None:
        """Construct a new count vectorizer using the sklearn framework."""
        super(CountVectorsFeaturizer, self).__init__(component_config)

        # parameters for sklearn's CountVectorizer
        self._load_count_vect_params()

        # handling Out-Of-Vocabulary (OOV) words
        self._load_OOV_params()

        # warn that some of config parameters might be ignored
        self._check_analyzer()

        # declare class instance for CountVectorizer
        self.vectorizers = vectorizers

    def process(self, message: Message, **kwargs: Any) -> None:
        """Process incoming message and compute and set features"""
        if self.vectorizers is None:
            logger.error(
                "There is no trained CountVectorizer: "
                "component is either not trained or "
                "didn't receive enough training data"
            )
        else:
            message_text = self._get_message_text_by_attribute(
                message, attribute=MESSAGE_TEXT_ATTRIBUTE
            )

            bag = (
                self.vectorizers[MESSAGE_TEXT_ATTRIBUTE]
                    .transform([message_text])
                    .toarray()
                    .squeeze()
            )
            message.set(
                MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE],
                self._combine_with_existing_features(
                    message,
                    bag,
                    feature_name=MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE],
                ),
            )

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Text = None,
            model_metadata: Metadata = None,
            cached_component: Optional["CountVectorsFeaturizer"] = None,
            **kwargs: Any
    ) -> "CountVectorsFeaturizer":
        component_model_dir = os.path.join(model_dir, meta['name'])
        featurizer_file = os.path.join(component_model_dir, meta["featurizer_file"])
        if os.path.exists(featurizer_file):
            vocabulary = util.json_unpickle(featurizer_file)
            share_vocabulary = meta["use_shared_vocab"]
            if share_vocabulary:
                vectorizers = cls.create_shared_vocab_vectorizers(
                    token_pattern=meta["token_pattern"],
                    strip_accents=meta["strip_accents"],
                    lowercase=meta["lowercase"],
                    stop_words=meta["stop_words"],
                    ngram_range=(meta["min_ngram"], meta["max_ngram"]),
                    max_df=meta["max_df"],
                    min_df=meta["min_df"],
                    max_features=meta["max_features"],
                    analyzer=meta["analyzer"],
                    vocabulary=vocabulary
                )
            else:
                vectorizers = cls.create_independent_vocab_vectorizers(
                    token_pattern=meta["token_pattern"],
                    strip_accents=meta["strip_accents"],
                    lowercase=meta["lowercase"],
                    stop_words=meta["stop_words"],
                    ngram_range=(meta["min_ngram"], meta["max_ngram"]),
                    max_df=meta["max_df"],
                    min_df=meta["min_df"],
                    max_features=meta["max_features"],
                    analyzer=meta["analyzer"],
                    vocabulary=vocabulary
                )
            return cls(meta, vectorizers)
        else:
            return cls(meta)

    def _check_analyzer(self):
        if self.analyzer != "word":
            if self.OOV_token is not None:
                logger.warning(
                    "Analyzer is set to character, "
                    "provided OOV word token will be ignored."
                )
            if self.stop_words is not None:
                logger.warning(
                    "Analyzer is set to character, "
                    "provided stop words will be ignored."
                )
            if self.max_ngram == 1:
                logger.warning(
                    "Analyzer is set to character, "
                    "but max n-gram is set to 1. "
                    "It means that the vocabulary will "
                    "contain single letters only."
                )

    def _load_OOV_params(self):
        self.OOV_token = self.component_config["OOV_token"]
        self.OOV_words = self.component_config["OOV_words"]
        if self.OOV_words and not self.OOV_token:
            logger.error(
                "The list OOV_words={} was given, but "
                "OOV_token was not. OOV words are ignored."
                "".format(self.OOV_words)
            )
            self.OOV_words = []

        if self.lowercase and self.OOV_token:
            # convert to lowercase
            self.OOV_token = self.OOV_token.lower()
            if self.OOV_words:
                self.OOV_words = [w.lower() for w in self.OOV_words]

    def _load_count_vect_params(self):
        # Use shared vocabulary between text and all other attributes of Message
        self.use_shared_vocab = self.component_config["use_shared_vocab"]

        # set analyzer
        self.analyzer = self.component_config["analyzer"]

        # regular expression for tokens
        self.token_pattern = self.component_config["token_pattern"]

        # remove accents during the preprocessing step
        self.strip_accents = self.component_config["strip_accents"]

        # list of stop words
        self.stop_words = self.component_config["stop_words"]

        # min number of word occurancies in the document to add to vocabulary
        self.min_df = self.component_config["min_df"]

        # max number (fraction if float) of word occurancies
        # in the document to add to vocabulary
        self.max_df = self.component_config["max_df"]

        # set ngram range
        self.min_ngram = self.component_config["min_ngram"]
        self.max_ngram = self.component_config["max_ngram"]

        # limit vocabulary size
        self.max_features = self.component_config["max_features"]

        # if convert all characters to lowercase
        self.lowercase = self.component_config["lowercase"]

    @staticmethod
    def create_shared_vocab_vectorizers(
            token_pattern,
            strip_accents,
            lowercase,
            stop_words,
            ngram_range,
            max_df,
            min_df,
            max_features,
            analyzer,
            vocabulary=None,
    ) -> Dict[Text, "CountVectorizer"]:
        """Create vectorizers for all attributes with shared vocabulary"""
        shared_vectorizer = CountVectorizer(
            token_pattern=token_pattern,
            strip_accents=strip_accents,
            lowercase=lowercase,
            stop_words=stop_words,
            ngram_range=ngram_range,
            max_df=max_df,
            min_df=min_df,
            max_features=max_features,
            analyzer=analyzer,
            vocabulary=vocabulary,
        )
        attribute_vectorizers = {}
        for attribute in MESSAGE_ATTRIBUTES:
            attribute_vectorizers[attribute] = shared_vectorizer
        return attribute_vectorizers

    @staticmethod
    def create_independent_vocab_vectorizers(
            token_pattern,
            strip_accents,
            lowercase,
            stop_words,
            ngram_range,
            max_df,
            min_df,
            max_features,
            analyzer,
            vocabulary=None,
    ) -> Dict[Text, "CountVectorizer"]:
        """Create vectorizers for all attributes with independent vocabulary"""
        attribute_vectorizers = {}
        for attribute in MESSAGE_ATTRIBUTES:
            attribute_vocabulary = vocabulary[attribute] if vocabulary else None
            attribute_vectorizer = CountVectorizer(
                token_pattern=token_pattern,
                strip_accents=strip_accents,
                lowercase=lowercase,
                stop_words=stop_words,
                ngram_range=ngram_range,
                max_df=max_df,
                min_df=min_df,
                max_features=max_features,
                analyzer=analyzer,
                vocabulary=attribute_vocabulary,
            )
            attribute_vectorizers[attribute] = attribute_vectorizer
        return attribute_vectorizers

    def _get_message_text_by_attribute(
            self, message: "Message", attribute: Text = MESSAGE_TEXT_ATTRIBUTE
    ) -> Text:
        """Get processed text of attribute of a message"""
        if message.get(attribute) is None:
            # return empty string since sklearn countvectorizer does not like None object while training and predicting
            return ""
        tokens = self._get_message_tokens_by_attribute(message, attribute)
        text = self._process_text(tokens, attribute)
        text = self._replace_with_oov_token(text, attribute)
        return text

    def _replace_with_oov_token(self, text: Text, attribute: Text) -> Text:
        """Replace OOV words with OOV token"""
        if self.OOV_token and self.analyzer == 'word':
            text_tokens = text.split()
            if self._check_attribute_vocabulary(attribute) and self.OOV_token in self._get_attribute_vocabulary(attribute):
                # CountVectorizer is trained, process for prediction
                text_tokens = [
                    t if t in self._get_attribute_vocabulary_tokens(attribute) else self.OOV_token for t in text_tokens
                ]
            elif self.OOV_words:
                # CountVectorizer is not trained, process for train
                text_tokens = [
                    self.OOV_token if t in self.OOV_words else t for t in text_tokens
                ]
            text = " ".join(text_tokens)
        return text

    def _get_attribute_vocabulary_tokens(self, attribute: Text) -> Optional[List[Text]]:
        """Get all keys of vocabulary of an attribute"""
        attribute_vocabulary = self._get_attribute_vocabulary(attribute)
        try:
            return list(attribute_vocabulary.keys())
        except TypeError:
            return None

    def _get_attribute_vocabulary(self, attribute: Text) -> Optional[Dict[Text, int]]:
        """Get trained vocabulary from attribute's count vectorizer"""
        try:
            return self.vectorizers[attribute].vocabulary_
        except (AttributeError, TypeError):
            return None

    def _check_attribute_vocabulary(self, attribute: Text) -> bool:
        """Check if trained vocabulary exists in attribute's count vectorizer"""
        try:
            return hasattr(self.vectorizers[attribute], "vocabulary_")
        except (AttributeError, TypeError):
            return False

    def _process_text(
            self, tokens: List[Text], attribute: Text = MESSAGE_TEXT_ATTRIBUTE
    ) -> Text:
        """Apply processing and cleaning steps to text"""
        text = " ".join(tokens)
        if attribute == MESSAGE_INTENT_ATTRIBUTE:
            # Don't do any processing for intent attribute. Treat them as whole labels
            return text

        # replace all digits with NUMBER token
        text = re.sub(r"\b[0-9]+\b", "__NUMBER__", text)

        # convert to lowercase if necessary
        if self.lowercase:
            text = text.lower()
        return text

    @staticmethod
    def _get_message_tokens_by_attribute(
            message: "Message", attribute: Text
    ) -> List[Text]:
        """Get text tokens of an attribute of a message"""
        if message.get(MESSAGE_TOKENS_NAMES[attribute]):
            tokens = [t.text for t in message.get(MESSAGE_TOKENS_NAMES[attribute])]
        else:
            tokens = message.get(attribute).split()
        return tokens
