from fastapi import APIRouter
from app.api.endpoints import nlu_parse


router = APIRouter()
router.include_router(nlu_parse.router)
