import os
import logging
import numpy as np
import tensorflow as tf
from typing import Optional, Dict, Text, Any, List
from nlu.classifiers import IntentClassifier
from nlu.training_data.message import Message
from nlu.utils.util import read_json_file
from nlu.model import Metadata


logger = logging.getLogger(__name__)


class EmbeddingClassifier(IntentClassifier):

    defaults = {
        "hidden_size": 128,
        "num_epochs": 20,
        "validation_split": 0.2,
        "early_stopping_patience": 5,
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ["tensorflow"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            classifier: Optional[tf.keras.models.Sequential] = None,
            label2intent: Optional[Dict[Text, Any]] = None
    ):
        super(EmbeddingClassifier, self).__init__(component_config)
        self.classifier = classifier
        self.label2intent = label2intent

    def process(self, message: Message, **kwargs: Any) -> None:
        """Return the most likely intent and its probability for a message."""
        if not self.classifier:
            # component is either not trained or didn't
            # receive enough training data
            intent = None
            intent_ranking = []
        else:
            X = message.get("text_features").reshape(1, -1)
            probabilities = self.classifier.predict(X)
            probabilities = probabilities.flatten()
            sorted_indices = np.argsort(-probabilities).tolist()
            intent = {
                "name": self.label2intent[sorted_indices[0]],
                "confidence": float(probabilities[sorted_indices[0]]),
                "recognizer": self.name
            }
            intent_ranking = [
                {
                    "name": self.label2intent[label],
                    "confidence": float(probabilities[label])
                } for label in sorted_indices[:self.LABEL_RANKING_LENGTH]
            ]
        recognized_intent = message.get('intent')
        if intent['name'] == recognized_intent['name'] and intent['confidence'] < recognized_intent['confidence']:
            return
        message.set("intent", intent, add_to_output=True)
        message.set("intent_ranking", intent_ranking, add_to_output=True)

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["EmbeddingClassifier"] = None,
            **kwargs: Any
    ):
        tf_model_dir = meta.get("tf_model_dir")
        if not os.path.isdir(tf_model_dir):
            classifier = None
        else:
            classifier = tf.keras.models.load_model(tf_model_dir)
        if not os.path.exists(meta.get("label2intent_file")):
            label2intent = None
        else:
            label2intent = read_json_file(meta["label2intent_file"])
            label2intent = {int(key): value for key, value in label2intent.items()}
        return cls(meta, classifier, label2intent)

