from fastapi import APIRouter
from app.schemas.response import ParsedResult
from app.nlu.parser import parser


router = APIRouter()


@router.get('/intent-recognization/', response_model=ParsedResult)
def parse_intent(query: str):
    parsed_result = parser.parse(query)
    return ParsedResult(**parsed_result)
