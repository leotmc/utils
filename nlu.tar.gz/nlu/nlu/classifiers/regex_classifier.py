import os
import re
from typing import Optional, List, Dict, Text, Any
from nlu.utils.util import write_json_to_file
from nlu.utils.io import read_json_file
from nlu.classifiers import IntentClassifier
from nlu.training_data.data import TrainingData
from nlu.training_data.message import Message
from nlu.nlu_config import RasaNLUModelConfig
from nlu.model import Metadata


class RegexClassifier(IntentClassifier):

    provides = ["intent"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns: Optional[List[Dict[Text, Text]]] = None,
    ):
        super(RegexClassifier, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def train(
            self, training_data: TrainingData, config: RasaNLUModelConfig, **kwargs: Any
    ) -> None:
        self.known_patterns = training_data.intent_classification_regexs

    def process(self, message: Message, **kwargs: Any) -> None:
        for exp in self.known_patterns:
            match = re.search(exp["pattern"], message.text)
            if match is not None:
                intent = {"name": exp["name"], "confidence": 1.0, "recognizer": self.name}
                message.set("intent", intent, add_to_output=True)
                message.set('intent_ranking', [])

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
                Return the metadata necessary to load the model again."""
        file_name = file_name + ".pkl"
        regex_file = os.path.join(model_dir, file_name)
        write_json_to_file(regex_file, self.known_patterns, indent=4)

        return {"file": file_name}

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional["Metadata"] = None,
            cached_component: Optional["RegexClassifier"] = None,
            **kwargs: Any
    ):
        file_name = meta.get("file")
        regex_file = os.path.join(model_dir, file_name)
        if os.path.exists(regex_file):
            known_patterns = read_json_file(regex_file)
            return RegexClassifier(meta, known_patterns=known_patterns)
        else:
            return RegexClassifier(meta)
