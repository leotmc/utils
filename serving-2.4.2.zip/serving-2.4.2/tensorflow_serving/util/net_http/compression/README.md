Compression support
===================

This package provides C++ wrappers for compression libraries such as gzip, br.

APIs are subject to change but usage outside net_http is expected.

gzip_zlib.h
---------------------

Minimum APIs and implementation to support gzip Content-Encoding via zlib.
