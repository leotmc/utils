import os
import warnings
from typing import Optional, Dict, Text, Any
from nlu.utils.util import write_json_to_file
from nlu.extractors import EntityExtractor
from nlu.training_data.data import TrainingData
from nlu.nlu_config import NLUModelConfig


class EntitySynonymMapper(EntityExtractor):

    provides = ["entities"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            synonyms: Optional[Dict[Text, Any]] = None,
    ) -> None:
        super(EntitySynonymMapper, self).__init__(component_config)
        self.synonyms = synonyms if synonyms else {}

    def train(
            self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any
    ) -> None:
        for key, value in list(training_data.entity_synonyms.items()):
            self.add_entities_if_synonyms(key, value)
        for example in training_data.entity_examples:
            for entity in example.get("entities", []):
                entity_val = example.text[entity["start"]: entity["end"]]
                self.add_entities_if_synonyms(entity_val, str(entity.get("value")))

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        if self.synonyms:
            file_name = file_name + ".json"
            entity_synonyms_file = os.path.join(model_dir, file_name)
            write_json_to_file(
                entity_synonyms_file, self.synonyms, separators=(",", ": ")
            )
            return {"file": file_name}
        else:
            return {"file": None}

    def add_entities_if_synonyms(self, entity_a, entity_b):
        if entity_b is not None:
            original = str(entity_a)
            replacement = str(entity_b)
            if original != replacement:
                original = original.lower()
                if original in self.synonyms and self.synonyms[original] != replacement:
                    warnings.warn(
                        "Found conflicting synonym definitions "
                        "for {}. Overwriting target {} with {}. "
                        "Check your training data and remove "
                        "conflicting synonym definitions to "
                        "prevent this from happening."
                        "".format(
                            repr(original),
                            repr(self.synonyms[original]),
                            repr(replacement),
                        )
                    )
                self.synonyms[original] = replacement
