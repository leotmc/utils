from fastapi import Header
from config import auth_token
from app.core.exceptions import AuthenticationFailed


def verify_token(token: str = Header(...)):
    if token != auth_token:
        raise AuthenticationFailed()
