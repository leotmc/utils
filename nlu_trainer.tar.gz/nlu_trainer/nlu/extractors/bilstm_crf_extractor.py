import os
import tensorflow as tf
import tensorflow_addons as tf_ad
from typing import Optional, Text, Dict, Any
from sklearn.model_selection import train_test_split
from nlu.training_data.data import TrainingData
from nlu.extractors import EntityExtractor
from nlu.nlu_config import NLUModelConfig
from nlu.utils.util import read_file, write_json_to_file
from config import bilstm_crf_vocab_file


class BiLSTMCRFEntityExtractor(EntityExtractor):

    provides = ["entities"]

    defaults = {
        'embedding_size': 128,
        'hidden_size': 128,
        'batch_size': 32,
        'max_seq_length': 60,
        'validation_split': 0.2,
        'num_epochs': 55
    }

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            extractor: Optional["BiLSTMCRF"] = None,
            label2idx: Optional[Dict[Text, Any]] = None,
    ):
        super(BiLSTMCRFEntityExtractor, self).__init__(component_config)
        self.extractor = extractor
        self.label2idx = label2idx if label2idx is not None else dict()
        vocab = read_file(bilstm_crf_vocab_file)
        self.char2idx = {c: idx for idx, c in enumerate(vocab)}

    def train(self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any):

        if training_data.entity_examples:
            inputs, targets = self._prepare_training_data(training_data)
            num_classes = targets.shape[-1]
            self.extractor = BiLSTMCRF(
                hidden_size=self.component_config['hidden_size'],
                vocab_size=len(self.char2idx),
                embedding_size=self.component_config['embedding_size'],
                num_classes=num_classes
            )
            train_inputs, val_inputs, train_targets, val_targets = train_test_split(inputs, targets, test_size=self.component_config['validation_split'])
            train_dataset = tf.data.Dataset.from_tensor_slices((train_inputs, train_targets))
            train_dataset = train_dataset.shuffle(buffer_size=1000).batch(self.component_config['batch_size'], drop_remainder=True)
            global_step = 0
            for e in range(self.component_config['num_epochs']):
                for step, (batch_inputs, batch_targets) in enumerate(train_dataset):
                    loss, accuracy = self.train_step(batch_inputs, batch_targets)
                    global_step += 1
                    print('step:  {:3}, training   loss: {:.5f}, training   accuracy: {:.5f}'.format(global_step, loss, accuracy))
                val_logits, val_text_lens, val_log_likelihood = self.extractor(val_inputs, val_targets, training=True)
                val_loss = -tf.reduce_mean(val_log_likelihood)
                val_accuracy = self.compute_step_accuracy(val_logits, val_text_lens, val_targets)
                print('epoch: {:3}, validation loss: {:.5f}, validation accuracy: {:.5f}'.format(e, val_loss, val_accuracy))

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        tf_model_dir = os.path.join(model_dir, file_name)
        if not os.path.isdir(tf_model_dir):
            os.mkdir(tf_model_dir)
        tf.keras.models.save_model(self.extractor, tf_model_dir)
        label2idx_file = os.path.join(model_dir, file_name + '_label2idx.json')
        write_json_to_file(label2idx_file, self.label2idx)
        return {'tf_model_dir': tf_model_dir, 'label2idx_file': label2idx_file}

    def train_step(self, inputs, targets):
        with tf.GradientTape() as tape:
            logits, text_lens, log_likelihood = self.extractor(inputs, targets, training=True)
            loss = -tf.reduce_mean(log_likelihood)
        gradients = tape.gradient(loss, self.extractor.trainable_variables)
        tf.keras.optimizers.Adam(0.001).apply_gradients(zip(gradients, self.extractor.trainable_variables))
        accuracy = self.compute_step_accuracy(logits, text_lens, targets)
        return loss, accuracy

    def compute_step_accuracy(self, logits, text_lens, labels_batch):
        paths, accuracy = [], 0
        for logit, text_len, labels in zip(logits, text_lens, labels_batch):
            viterbi_path, _ = tf_ad.text.viterbi_decode(logit[:text_len], self.extractor.transition_params)
            paths.append(viterbi_path)
            correct_prediction = tf.equal(
                tf.convert_to_tensor(tf.keras.preprocessing.sequence.pad_sequences([viterbi_path], padding='post'),
                                     dtype=tf.int32),
                tf.convert_to_tensor(tf.keras.preprocessing.sequence.pad_sequences([labels[:text_len]], padding='post'),
                                     dtype=tf.int32)
            )
            accuracy = accuracy + tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
        accuracy = accuracy / len(paths)
        return accuracy

    def _prepare_training_data(self, training_data: TrainingData):
        inputs, targets = [], []
        label_set = set()
        for e in training_data.entity_examples:
            text = e.text
            text_index = [self.char2idx.get(c, 0) for c in text]
            text_label = ['O'] * len(text)
            entities = e.get("entities")
            for ent in entities:
                ent_name = ent['entity']
                ent_start = ent['start']
                ent_end = ent['end']
                for i in range(ent_start, ent_end):
                    text_label[i] = 'I-' + ent_name
                text_label[ent_start] = 'B-' + ent_name
            inputs.append(text_index)
            targets.append(text_label)
            label_set.update(text_label)
        label_set.add('<UNK>')
        self.label2idx = {l: i for i, l in enumerate(label_set)}
        targets = [[self.label2idx[l] for l in t] for t in targets]
        inputs = tf.keras.preprocessing.sequence.pad_sequences(inputs, padding='post', maxlen=self.component_config['max_seq_length'])
        targets = tf.keras.preprocessing.sequence.pad_sequences(targets, padding='post', maxlen=self.component_config['max_seq_length'])
        return inputs, targets


class BiLSTMCRF(tf.keras.Model):

    def __init__(self, hidden_size, vocab_size, embedding_size, num_classes):
        super(BiLSTMCRF, self).__init__()
        self.num_classes = num_classes
        self.embedding_layer = tf.keras.layers.Embedding(vocab_size, embedding_size)
        self.bilstm_layer = tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(hidden_size, return_sequences=True))
        self.dense_layer = tf.keras.layers.Dense(num_classes)
        self.dropout_layer = tf.keras.layers.Dropout(0.5)

    def build(self, input_shape):
        self.transition_params = tf.Variable(tf.random.uniform(shape=(self.num_classes, self.num_classes)))
        super(BiLSTMCRF, self).build(input_shape)

    @tf.function
    def call(self, inputs, labels=None, training=None):
        inputs_lens = tf.math.reduce_sum(tf.cast(tf.math.not_equal(inputs, 0), dtype=tf.int32), axis=-1)
        embedded = self.embedding_layer(inputs)
        dropout = self.dropout_layer(embedded)
        logits = self.dense_layer(self.bilstm_layer(dropout))
        if labels is not None:
            label_sequences = tf.convert_to_tensor(labels, dtype=tf.int32)
            log_likelihood, self.transition_params = tf_ad.text.crf_log_likelihood(
                logits, label_sequences, inputs_lens, transition_params=self.transition_params
            )
            return logits, inputs_lens, log_likelihood
        else:
            return logits, inputs_lens
