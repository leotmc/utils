import nmslib
from typing import Optional, Dict, Text, Any
from nlu.classifiers import IntentClassifier
from nlu.bert.bert_serving import serve
from nlu.bert.bert_tokenization import FullTokenizer
from nlu.training_data.message import Message
from nlu.model import Metadata
from nlu.utils.util import read_json_file
from config import bert_vocab_file, bert_serving_host, bert_serving_port, bert_serving_model_name


class IntentSimilarityCorrector(IntentClassifier):
    defaults = {
        "bert_serving_url": "http://{}:{}/v1/models/{}:predict".format(bert_serving_host, bert_serving_port, bert_serving_model_name),
        "bert_featurizer_max_seq_length": 25,
        "bert_featurizer_batch_size": 32,
        "similar_intent_distance_threshold": 0.02,
        "un_similar_intent_distance_threshold": 0.05
    }

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            ind2intent: Optional[Dict[Text, Any]] = None,
            nmslib_index: "nmslib.dist.FloatIndex" = None
    ):
        super(IntentSimilarityCorrector, self).__init__(component_config)
        self.tokenizer_for_bert = FullTokenizer(bert_vocab_file)
        self.ind2intent = ind2intent
        self.nmslib_index = nmslib_index

    def process(self, message: Message, **kwargs: Any) -> None:
        bert_serving_response = serve(
            tokenizer=self.tokenizer_for_bert,
            sentences=[message.text],
            serving_url=self.component_config["bert_serving_url"],
            max_seq_length=self.component_config["bert_featurizer_max_seq_length"],
            batch_size=self.component_config["bert_featurizer_batch_size"]
        )
        text_feature = bert_serving_response[0]['pooled_feature']
        ids, distances = self.nmslib_index.knnQuery(text_feature, k=1)
        recognized_intent = message.get('intent')
        most_similar_intent = self.ind2intent[ids[0]]
        most_similar_intent_distance = distances[0]
        if most_similar_intent_distance >= self.component_config['un_similar_intent_distance_threshold']:
            message.set('intent', {'name': None, 'confidence': 0.0, 'recognizer': self.name}, add_to_output=True)
            message.set('intent_ranking', [])
        elif most_similar_intent_distance <= self.component_config['similar_intent_distance_threshold']:
            # Even if the two intent is the same,
            # the distance computed by nmslib is a very small float value instead zero
            if abs(most_similar_intent_distance - 0.0) <= 1e-5:
                message.set('intent', {'name': most_similar_intent, 'confidence': 1.0, 'recognizer': self.name})
                message.set('intent_ranking', [])
            elif most_similar_intent != recognized_intent:
                message.set('intent', {'name': most_similar_intent, 'confidence': 0.8, 'recognizer': self.name})
                message.set('intent_ranking', [])

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["IntentSimilarityCorrector"] = None,
            **kwargs: Any
    ):
        ind2intent_file = meta['ind2intent_file']
        nmslib_index_file = meta['nmslib_index_file']
        ind2intent = read_json_file(ind2intent_file)
        ind2intent = {int(ind): intent for ind, intent in ind2intent.items()}
        nmslib_index = nmslib.init(method='hnsw', space='cosinesimil')
        nmslib_index.loadIndex(nmslib_index_file, load_data=True)
        return cls(meta, ind2intent, nmslib_index)
