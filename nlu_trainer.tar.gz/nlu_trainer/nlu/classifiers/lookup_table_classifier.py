import os
import typing
from typing import Optional, Dict, List, Text, Any
from nlu.utils import util
from nlu.classifiers import IntentClassifier
from nlu.training_data.data import TrainingData
from nlu.nlu_config import NLUModelConfig
from nlu.utils.trie import build_trie


if typing.TYPE_CHECKING:
    from dawg import IntDAWG


class LookupTableClassifier(IntentClassifier):

    provides = ["intent"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            trie_map: Optional[Dict[Text, "IntDAWG"]] = None,
    ):
        super(LookupTableClassifier, self).__init__(component_config)
        self.trie_map = trie_map if trie_map else dict()

    def train(
            self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any
    ) -> None:
        self._build_trie_map(training_data.intent_classification_lookup_tables)

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
        Return the metadata necessary to load the model again."""
        file_name = file_name + '.pkl'
        trie_map_file = os.path.join(model_dir, file_name)
        util.json_pickle(trie_map_file, self.trie_map)
        return {"file": file_name}

    def _build_trie_map(self, lookup_tables: List[Dict[Text, Any]]):
        for table in lookup_tables:
            name = table['name']
            elements = table['elements']
            trie = build_trie(elements)
            self.trie_map[name] = trie
