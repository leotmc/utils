from fastapi import status
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse


class NotAuthenticated(Exception):

    status_code = status.HTTP_401_UNAUTHORIZED
    description = 'Authentication credentials were not provided.'

    def __init__(self, description=None):
        if description is not None:
            self.description = description


class AuthenticationFailed(Exception):

    status_code = status.HTTP_401_UNAUTHORIZED
    description = 'Incorrect authentication credentials.'

    def __init__(self, description=None):
        if description is not None:
            self.description = description


def register_error_handlers(app: FastAPI):

    @app.exception_handler(AuthenticationFailed)
    def handle_authenticate_fail(request: Request, e: AuthenticationFailed):
        return JSONResponse(
            status_code=e.status_code,
            content={'message': e.description}
        )

    @app.exception_handler(NotAuthenticated)
    def handle_not_authenticated(request: Request, e: NotAuthenticated):
        return JSONResponse(
            status_code=e.status_code,
            content={'message': e.description}
        )

    return app
