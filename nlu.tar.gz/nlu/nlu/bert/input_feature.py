class InputFeatures(object):

    def __init__(self, input_ids, input_mask, segment_ids, label_ids):
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.segment_ids = segment_ids
        self.label_ids = label_ids


def convert_sentence_to_features(tokenizer, sentences, max_seq_length, task="classification"):
    features = []
    for i, sentence in enumerate(sentences):
        sentence_tokens = tokenizer.tokenize(sentence)
        # Account for [CLS] and [SEP] with "- 2"
        if len(sentence_tokens) > max_seq_length - 2:
            sentence_tokens = sentence_tokens[0: max_seq_length - 2]
        tokens, segment_ids = [], []
        tokens.append('[CLS]')
        segment_ids.append(0)
        for token in sentence_tokens:
            tokens.append(token)
            segment_ids.append(0)
        tokens.append('[SEP]')
        segment_ids.append(0)

        input_ids = tokenizer.convert_tokens_to_ids(tokens)

        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        input_mask = [1] * len(input_ids)

        # Zero-pad up to the sequence length.
        while len(input_ids) < max_seq_length:
            input_ids.append(0)
            input_mask.append(0)
            segment_ids.append(0)

        if task == "classification":
            label_ids = 0
        elif task == "sequence_tagging":
            label_ids = [0] * max_seq_length
        else:
            raise NotImplementedError('Do not support task: "{}"'.format(task))

        feature = InputFeatures(
            input_ids=input_ids,
            input_mask=input_mask,
            segment_ids=segment_ids,
            label_ids=label_ids
        )
        features.append(feature)
    return features
