from enum import Enum


class Task(Enum):
    COMPLAINT_CLASSIFICATION = 'complaint_classification'
    DEPARTMENT_CLASSIFICATION = 'department_classification'
    SIMCSE = 'simcse'


SUPPORT_TASKS = [member.value for _, member in Task.__members__.items()]

DEFAULT_RECOMMENDATION_SIZE = 5
COMPLAINT_MAX_LENGTH = 512
