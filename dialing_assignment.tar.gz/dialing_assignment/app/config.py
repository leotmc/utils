import os
from configparser import ConfigParser

root_dir = os.path.dirname(__file__)
data_dir = os.path.join(root_dir, '../data')
model_dir = os.path.join(root_dir, '../model')
log_dir = os.path.join(root_dir, '../logs')
conf_dir = os.path.join(root_dir, '../conf')
config_file = os.path.join(conf_dir, 'dialing_assignment.conf')
conf = ConfigParser()
conf.read([config_file])

module_name = conf.get('DEFAULT', 'module_name')

# data
data_file = os.path.join(data_dir, conf.get('DATA', 'data_file'))
complaint_train_file = os.path.join(data_dir, conf.get('DATA', 'complaint_train_file'))
complaint_dev_file = os.path.join(data_dir, conf.get('DATA', 'complaint_dev_file'))
complaint_test_file = os.path.join(data_dir, conf.get('DATA', 'complaint_test_file'))
complaint_label_category_mapping_file = os.path.join(data_dir, conf.get('DATA', 'complaint_label_category_mapping_file'))
department_train_file = os.path.join(data_dir, conf.get('DATA', 'department_train_file'))
department_dev_file = os.path.join(data_dir, conf.get('DATA', 'department_dev_file'))
department_test_file = os.path.join(data_dir, conf.get('DATA', 'department_test_file'))
department_label_category_mapping_file = os.path.join(data_dir, conf.get('DATA', 'department_label_category_mapping_file'))
complaint_department_mapping_file = os.path.join(data_dir, conf.get('DATA', 'complaint_department_mapping_file'))
department_complaint_mapping_file = os.path.join(data_dir, conf.get('DATA', 'department_complaint_mapping_file'))
code_department_mapping_file = os.path.join(data_dir, conf.get('DATA', 'code_department_mapping_file'))
tencent_embedding_file = os.path.join(data_dir, conf.get('DATA', 'tencent_embedding_file'))
simcse_label_clusters_file = os.path.join(data_dir, conf.get('DATA', 'simcse_label_clusters_file'))
word2vec_label_clusters_file = os.path.join(data_dir, conf.get('DATA', 'word2vec_label_clusters_file'))

# model
simcse_pt_model_dir = os.path.join(model_dir, conf.get('MODEL', 'simcse_pt_model_dir'))
simcse_tf_model_dir = os.path.join(model_dir, conf.get('MODEL', 'simcse_tf_model_dir'))
department_classification_pt_model_dir = os.path.join(model_dir, conf.get('MODEL', 'department_classification_pt_model_dir'))
department_classification_tf_model_dir = os.path.join(model_dir, conf.get('MODEL', 'department_classification_tf_model_dir'))
complaint_classification_pt_model_dir = os.path.join(model_dir, conf.get('MODEL', 'complaint_classification_pt_model_dir'))
complaint_classification_tf_model_dir = os.path.join(model_dir, conf.get('MODEL', 'complaint_classification_tf_model_dir'))

# tf serving
tf_serving_host = conf.get('TF_SERVING', 'host')
tf_serving_port = conf.getint('TF_SERVING', 'port')
simcse_model_name = conf.get('TF_SERVING', 'simcse_model_name')
complaint_classification_model_name = conf.get('TF_SERVING', 'complaint_classification_model_name')
department_classification_model_name = conf.get('TF_SERVING', 'department_classification_model_name')
