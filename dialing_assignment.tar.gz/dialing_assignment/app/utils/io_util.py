import json
from app.config import complaint_label_category_mapping_file, department_label_category_mapping_file


def read_json(file):
    with open(file, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_file(file):
    with open(file, 'r', encoding='utf-8') as f:
        return f.read().split('\n')


def write_file(data, file):
    with open(file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(data))


def write_json(data, file):
    with open(file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


complaint_label_category_mapping = read_json(complaint_label_category_mapping_file)
department_label_category_mapping = read_json(department_label_category_mapping_file)
