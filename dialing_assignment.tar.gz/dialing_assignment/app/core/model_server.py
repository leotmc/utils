import math
import json
import requests
from scipy.special import softmax
from transformers import AutoTokenizer
from app.config import (
    tf_serving_host,
    tf_serving_port,
    simcse_model_name,
    complaint_classification_model_name,
    department_classification_model_name,
    simcse_pt_model_dir,
    complaint_classification_pt_model_dir,
    department_classification_pt_model_dir
)
from app.constants import Task, COMPLAINT_MAX_LENGTH
from app.exceptions import InvalidTask


class ModelServer(object):

    def __init__(self):
        self.simcse_url = f'http://{tf_serving_host}:{tf_serving_port}/v1/models/{simcse_model_name}:predict'
        self.complaint_classification_url = f'http://{tf_serving_host}:{tf_serving_port}/v1/models/{complaint_classification_model_name}:predict'
        self.department_classification_url = f'http://{tf_serving_host}:{tf_serving_port}/v1/models/{department_classification_model_name}:predict'
        self.simcse_tokenizer = AutoTokenizer.from_pretrained(simcse_pt_model_dir)
        self.complaint_tokenizer = AutoTokenizer.from_pretrained(complaint_classification_pt_model_dir)
        self.department_tokenizer = AutoTokenizer.from_pretrained(department_classification_pt_model_dir)

    def serve(self, samples, task, batch_size=32):
        num_samples = len(samples)
        num_batches = math.ceil(num_samples / batch_size)
        results = []
        for i in range(num_batches):
            batch_samples = samples[i * batch_size: min((i + 1) * batch_size, num_samples)]
            # +2 for [SEP] and [CLS] token
            max_length = min(max([len(s) for s in batch_samples]) + 2, COMPLAINT_MAX_LENGTH)
            if task == Task.SIMCSE.value:
                batch_results = self._serve(batch_samples, self.simcse_url, self.simcse_tokenizer, max_length=max_length, field='pooler_output')
            elif task == Task.COMPLAINT_CLASSIFICATION.value:
                batch_results = self._serve(batch_samples, self.complaint_classification_url, self.complaint_tokenizer, max_length=max_length, field='predictions')
            elif task == Task.DEPARTMENT_CLASSIFICATION.value:
                batch_results = self._serve(batch_samples, self.department_classification_url, self.department_tokenizer, max_length=max_length, field='predictions')
            else:
                raise InvalidTask()
            results.extend(batch_results)
        return results

    @staticmethod
    def _serve(batch_samples, url, tokenizer, max_length, field):
        tokenized_results = tokenizer(batch_samples, max_length=max_length, truncation=True, padding='max_length')
        instances = []
        for input_id, token_type_id, attention_mask in zip(tokenized_results['input_ids'],
                                                           tokenized_results['token_type_ids'],
                                                           tokenized_results['attention_mask']):
            instances.append({'input_ids': input_id, 'token_type_ids': token_type_id, 'attention_mask': attention_mask})
        data = json.dumps({'signature_name': 'serving_default', 'instances': instances})
        response = requests.post(url, data=data, headers={'content-type': 'application/json'})
        return json.loads(response.text)[field]


model_server = ModelServer()


if __name__ == '__main__':
    samples = [
        '老板无故辞退其，还拿走手机，需要解决，协同政府。',
        '接通无应答，回拨称有一名男子及三名女子过去闹事，称未发工资提升。'
    ]
    res = model_server.serve(samples, task='complaint_classification')
    print(softmax(res, axis=1))
    print('*')
