import os
import multiprocessing


bind = '0.0.0.0:%s' % os.environ.get('PORT', 5007)
workers = multiprocessing.cpu_count()
timeout = os.environ.get('GUNICORN_TIMEOUT', 120)
worker_class = 'uvicorn.workers.UvicornWorker'
worker_connections = os.environ.get('GUNICORN_WORKER_CONN', 1000)
keepalive = os.environ.get('GUNICORN_KEEPALIVE', 5)


errorlog = '-'
loglevel = 'info'
accesslog = '-'
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'
