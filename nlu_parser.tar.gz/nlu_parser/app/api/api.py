from fastapi import APIRouter
from app.api.endpoints import parse


router = APIRouter()
router.include_router(parse.router)
