from typing import Optional, Dict, Text, Any
from nlu.featurizers import Featurizer
from nlu.training_data.message import Message
from nlu.bert.bert_tokenization import FullTokenizer
from nlu.bert.bert_serving import serve
from config import bert_serving_host, bert_serving_port, bert_serving_model_name
from nlu.constants import (
    MESSAGE_VECTOR_FEATURE_NAMES,
    MESSAGE_TEXT_ATTRIBUTE
)
from config import bert_vocab_file


class BertFeaturizer(Featurizer):

    provides = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    defaults = {
        "bert_serving_url": "http://{}:{}/v1/models/{}:predict".format(bert_serving_host, bert_serving_port, bert_serving_model_name),
        "max_seq_length": 25,
        "batch_size": 32,
    }

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
    ):
        super(BertFeaturizer, self).__init__(component_config)
        self.tokenizer_for_bert = FullTokenizer(bert_vocab_file)

    def process(self, message: Message, **kwargs: Any):
        bert_serving_response = serve(
            tokenizer=self.tokenizer_for_bert,
            sentences=[message.text],
            serving_url=self.component_config["bert_serving_url"],
            max_seq_length=self.component_config["max_seq_length"],
            batch_size=self.component_config["batch_size"]
        )
        message.set(
            MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE],
            self._combine_with_existing_features(
                message,
                bert_serving_response[0]["pooled_feature"],
                MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]
            )
        )
