import os
import glob
import jieba
import shutil
import logging
from typing import Dict, Text, Any, List, Optional

from nlu.tokenizers import Token, Tokenizer
from nlu.components import Component
from nlu.constants import (
    MESSAGE_ATTRIBUTES,
    MESSAGE_TOKENS_NAMES,
    MESSAGE_TEXT_ATTRIBUTE,
    MESSAGE_INTENT_ATTRIBUTE
)
from nlu.nlu_config import NLUModelConfig
from nlu.training_data.data import TrainingData


logger = logging.getLogger(__name__)


class JiebaTokenizer(Tokenizer, Component):

    provides = [MESSAGE_TOKENS_NAMES[attribute] for attribute in MESSAGE_ATTRIBUTES]

    language_list = ['zh']

    defaults = {
        "dictionary_path": None,
        "intent_tokenization_flag": False,
        "intent_split_symbol": "_"
    }

    def __init__(self, component_config: Dict[Text, Any] = None) -> None:
        super(JiebaTokenizer, self).__init__(component_config)
        self.dictionary_path = self.component_config.get("dictionary_path")
        self.intent_tokenization_flag = self.component_config.get("intent_tokenization_flag")
        self.intent_split_symbol = self.component_config.get("intent_split_symbol")
        if self.dictionary_path is not None:
            self.load_custom_dictionary(self.dictionary_path)

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ["jieba"]

    @staticmethod
    def load_custom_dictionary(path: Text) -> None:
        jieba_userdicts = glob.glob("{}/*".format(path))
        for jieba_userdict in jieba_userdicts:
            logger.info("Loading Jieba User Dictionary at {}".format(jieba_userdict))
            jieba.load_userdict(jieba_userdict)

    def train(
            self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any
    ) -> None:
        for example in training_data.training_examples:
            for attribute in MESSAGE_ATTRIBUTES:
                if example.get(attribute) is not None:
                    example.set(
                        MESSAGE_TOKENS_NAMES[attribute],
                        self.tokenize(example.get(attribute), attribute)
                    )

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        if self.dictionary_path is not None:
            target_dictionary_path = os.path.join(model_dir, file_name)
            self.copy_files_dir_to_dir(self.dictionary_path, target_dictionary_path)
            return {"dictionary_path": file_name}
        else:
            return {"dictionary_path": None}

    def preprocess_text(self, text, attribute):
        if attribute == MESSAGE_INTENT_ATTRIBUTE and self.intent_tokenization_flag:
            return " ".join(text.split(self.intent_split_symbol))
        else:
            return text

    def tokenize(self, text: Text, attribute=MESSAGE_TEXT_ATTRIBUTE) -> List[Token]:
        text = self.preprocess_text(text, attribute)
        tokenized = jieba.tokenize(text)
        tokens = [Token(word, start) for (word, start, end) in tokenized]
        return tokens

    @staticmethod
    def copy_files_dir_to_dir(input_dir, output_dir):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        target_file_list = glob.glob("{}/*".format(input_dir))
        for target_file in target_file_list:
            shutil.copy2(target_file, output_dir)
