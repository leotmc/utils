from typing import List, Optional
from pydantic import BaseModel


class Intent(BaseModel):
    name: Optional[str] = None
    confidence: float
    recognizer: Optional[str] = None


class Entity(BaseModel):
    start: int
    end: int
    value: str
    entity: str
    confidence: float
    extractor: Optional[str] = None
    processor: Optional[List[str]] = None


class ParsedResult(BaseModel):
    intent: Intent
    entities: List[Entity] = list()
    intent_ranking: List[Intent] = list()
    text: str

