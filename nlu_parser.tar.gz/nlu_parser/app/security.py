from fastapi import Header
from app.config import auth_token
from app.exceptions import AuthenticationFailed


def verify_token(token: str = Header(...)):
    if token != auth_token:
        raise AuthenticationFailed()
