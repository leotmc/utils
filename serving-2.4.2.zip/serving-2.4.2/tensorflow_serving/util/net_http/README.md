A (truly) lightweight OSS HTTP Server
=====================================

Design and implementation started in April 2018, within the TF serving code base.

APIs are subject to change.

Questions?
----------

If you have any questions, please send them to [web|awk]@google.com
