from fastapi import APIRouter
from app.api.endpoints import parser


router = APIRouter()
router.include_router(parser.router)
