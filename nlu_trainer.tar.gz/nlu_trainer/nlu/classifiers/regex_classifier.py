import os
from typing import Optional, List, Dict, Text, Any
from nlu.utils.util import write_json_to_file
from nlu.classifiers import IntentClassifier
from nlu.training_data.data import TrainingData
from nlu.nlu_config import NLUModelConfig


class RegexClassifier(IntentClassifier):

    provides = ["intent"]

    def __init__(
            self,
            component_config: Optional[Dict[Text, Text]] = None,
            known_patterns: Optional[List[Dict[Text, Text]]] = None,
    ):
        super(RegexClassifier, self).__init__(component_config)
        self.known_patterns = known_patterns if known_patterns else []

    def train(
            self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any
    ) -> None:
        self.known_patterns = training_data.intent_classification_regexs

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory.
                Return the metadata necessary to load the model again."""
        file_name = file_name + ".pkl"
        regex_file = os.path.join(model_dir, file_name)
        write_json_to_file(regex_file, self.known_patterns, indent=4)

        return {"file": file_name}
