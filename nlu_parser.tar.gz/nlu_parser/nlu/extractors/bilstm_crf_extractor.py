import tensorflow as tf
import tensorflow_addons as tf_ad
from typing import Optional, Text, Dict, Any
from nlu.training_data.message import Message
from nlu.extractors import EntityExtractor
from nlu.model import Metadata
from nlu.utils.util import read_file, read_json_file
from config import bilstm_crf_vocab_file


class BiLSTMCRFEntityExtractor(EntityExtractor):

    provides = ["entities"]

    defaults = {
        'embedding_size': 128,
        'hidden_size': 128,
        'batch_size': 32,
        'max_seq_length': 60,
        'validation_split': 0.2,
        'num_epochs': 55
    }

    def __init__(
            self,
            component_config: Optional[Dict[Text, Any]] = None,
            extractor: Optional["tf.keras.Model"] = None,
            label2idx: Optional[Dict[Text, Any]] = None,
    ):
        super(BiLSTMCRFEntityExtractor, self).__init__(component_config)
        self.extractor = extractor
        self.label2idx = label2idx if label2idx is not None else dict()
        vocab = read_file(bilstm_crf_vocab_file)
        self.char2idx = {c: idx for idx, c in enumerate(vocab)}

    def process(self, message: Message, **kwargs: Any) -> None:
        extracted = self.add_extractor_name(self.extract_entities(message))
        message.set(
            "entities",
            message.get("entities", []) + extracted,
            add_to_output=True
        )

    @classmethod
    def load(
            cls,
            meta: Dict[Text, Any],
            model_dir: Optional[Text] = None,
            model_metadata: Optional[Metadata] = None,
            cached_component: Optional["BiLSTMCRFEntityExtractor"] = None,
            **kwargs: Any
    ):
        label2idx_file = meta['label2idx_file']
        label2idx = read_json_file(label2idx_file)
        tf_model_dir = meta['tf_model_dir']
        extractor = tf.keras.models.load_model(tf_model_dir)
        return cls(meta, extractor, label2idx)

    def extract_entities(self, message: Message):
        text_index = [self.char2idx.get(c, 0) for c in message.text]
        text_index = tf.keras.preprocessing.sequence.pad_sequences([text_index], padding='post',
                                                                   maxlen=self.component_config['max_seq_length'])
        logits, inputs_lens = self.extractor.predict(text_index)
        paths = []
        for logit, input_len in zip(logits, inputs_lens):
            viterbi_path, _ = tf_ad.text.viterbi_decode(logit[:input_len], self.extractor.transition_params)
            paths.append(viterbi_path)
        ind2label = {index: label for label, index in self.label2idx.items()}
        predict_labels = [ind2label[index] for index in paths[0]]
        if set(predict_labels) == 'O':
            return []
        entity_set = set()
        start_pos, end_pos = None, None
        for i, label in enumerate(predict_labels):
            if label.startswith('B'):
                start_pos = i
            if label != 'O':
                entity_set.add(label.split('-')[-1])
                end_pos = i
        if start_pos is None:
            return []
        end_pos = end_pos + 1 if end_pos is not None else start_pos + 1
        if len(entity_set) != 1:
            return []
        end_pos = start_pos + 1 if end_pos is None else end_pos
        return [{
            'start': start_pos,
            'end': end_pos,
            'value': message.text[start_pos: end_pos],
            'entity': entity_set.pop(),
            'confidence': 0.8
        }]
