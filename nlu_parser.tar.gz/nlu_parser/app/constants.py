from enum import Enum
from collections import defaultdict


NUMERIC_PROPERTIES = {
    'currency_less_than', 'currency_equal', 'currency_more_than', 'currency_between',
    'time_less_than', 'time_equal', 'time_more_than', 'time_between',
    'distance_less_than', 'distance_equal', 'distance_more_than', 'distance_between',
    'age_less_than', 'age_equal', 'age_more_than', 'age_between',
    'digit_less_than', 'digit_equal', 'digit_more_than', 'digit_between',
    'area_less_than', 'area_equal', 'area_more_than', 'area_between',
    'floor_less_than', 'floor_equal', 'floor_more_than', 'floor_between'
}


UNIT2RATIO = {
    '天': 1.0,
    '周': 7.0,
    '星期': 7.0,
    '月': 30.0,
    '半年': 183.0,
    '年': 365.0,
    '米': 1.0,
    '里': 500.0,
    '千米': 1000.0,
    '公里': 1000.0
}
CHINESE2NUMBER = {'半': 0.5, '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9}
CHINESE2UNIT = {'十': 10, '百': 100, '千': 1000, '万': 10000, '亿': 100000000}

NODE_PROPERTIES = {
    "registered_capital": {"node": "company", "is_countable": True, "matched_numeric_conditions": ["currency_less_than", "currency_equal", "currency_more_than", "currency_between"]},
    "opfyears": {"node": "company", "is_countable": True, "matched_numeric_conditions": ["time_less_than", "time_equal", "time_more_than", "time_between"]},
    "industry_categories": {"node": "company", "is_countable": False},
    "company_label": {"node": "company", "is_countable": False},
    "sex": {"node": "person", "is_countable": False},
    "age": {"node": "person", "is_countable": True, "matched_numeric_conditions": ["age_less_than", "age_equal", "age_more_than", "age_between"]},
    "education_level": {"node": "person", "is_countable": False},
    "persname": {"node": "person", "is_countable": False},
    "marriage_status": {"node": "person", "is_countable": False},
    "retiree": {"node": "person", "is_countable": False},
    "nation": {"node": "person", "is_countable": False},
    "political_outlook": {"node": "person", "is_countable": False},
    "registered_residence_type": {"node": "person", "is_countable": False},
    "live_status": {"node": "person", "is_countable": False},
    "person_label": {"node": "person", "is_countable": False},
    "event_label": {"node": "event", "is_countable": False},
    "detail_type": {"node": "event", "is_countable": False},
    "floor_type": {"node": "building", "is_countable": False},
    "building_structure": {"node": "building", "is_countable": False},
    "intent_use_type": {"node": "building", "is_countable": False},
    "building_type": {"node": "building", "is_countable": False},
    "building_kind": {"node": "building", "is_countable": False},
    "stairs_type": {"node": "building", "is_countable": False},
    "construction_status": {"node": "building", "is_countable": False},
    "live_type": {"node": "building", "is_countable": False},
    "usage_type": {"node": "building", "is_countable": False},
    "house_nums": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["digit_less_than", "digit_equal", "digit_more_than", "digit_between"]},
    "public_nums": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["digit_less_than", "digit_equal", "digit_more_than", "digit_between"]},
    "total_building_area": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "upground_layer": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["floor_less_than", "floor_equal", "floor_more_than", "floor_between"]},
    "underground_layer": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["floor_less_than", "floor_equal", "floor_more_than", "floor_between"]},
    "upground_area": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "underground_area": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "typical_floor_area": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "land_occupation_area": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "building_height": {"node": "building", "is_countable": True, "matched_numeric_conditions": ["distance_less_than", "distance_equal", "distance_more_than", "distance_between"]},
    "building_status": {"node": "building", "is_countable": False},
    "building_star": {"node": "building", "is_countable": False},
    "hire_status_flag": {"node": "building", "is_countable": False},
    "housearea": {"node": "house", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "livearea": {"node": "house", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "businessarea": {"node": "house", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "officearea": {"node": "house", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "factoryarea": {"node": "house", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "storearea": {"node": "house", "is_countable": True, "matched_numeric_conditions": ["area_less_than", "area_equal", "area_more_than", "area_between"]},
    "house_label": {"node": "house", "is_countable": False}
}


def create_property_mapping():
    """建立数值属性与非数值属性之间的映射关系"""
    mapping = defaultdict(set)
    for key, value in NODE_PROPERTIES.items():
        for condition in value.get('matched_numeric_conditions', []):
            mapping[condition].add(key)
    # 当一个数值类型的属性对应有多个非数值类型的属性的时候，取默认的非数值属性
    default_properties = {'house_nums', 'housearea', 'upground_layer'}
    for key, value in mapping.items():
        if len(value) == 1:
            mapping[key] = value.pop()
        else:
            mapping[key] = (value & default_properties).pop()
    return mapping


PROPERTY_MAPPING = create_property_mapping()


class IntentMode(Enum):
    ST = 'ST'
    MT = 'MT'


class Node(Enum):
    COMPANY = 'company'
    EVENT = 'event'
    PERSON = 'person'
    HOUSE = 'house'
    BUILDING = 'building'
    STREET = 'street'
    COMMUNITY = 'community'
    GRID = 'grid'


NODES = [member.value for _, member in Node.__members__.items()]


ENUMERABLE_PROPERTIES = {'company_label', 'industry_categories', 'building', 'street', 'grid'}
