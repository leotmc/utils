import os
import logging
import numpy as np
from typing import Dict, Text, Any, Optional, List
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from nlu.classifiers import IntentClassifier
from nlu.training_data.data import TrainingData
from nlu.nlu_config import NLUModelConfig
from nlu.utils.util import json_pickle
from nlu.constants import (
    MESSAGE_VECTOR_FEATURE_NAMES,
    MESSAGE_TEXT_ATTRIBUTE
)

logger = logging.getLogger(__name__)


class SVMClassifier(IntentClassifier):
    """Classify intent with SVM."""

    provides = ["intent", "intent_ranking"]

    requires = [MESSAGE_VECTOR_FEATURE_NAMES[MESSAGE_TEXT_ATTRIBUTE]]

    defaults = {
        # C parameter of the svm - cross validation will select the best value
        "C": [1, 2, 5, 10, 20, 100],
        # gamma parameter of the svm
        "gamma": [0.1],
        # the kernels to use for the svm training - cross validation will
        # decide which one of them performs best
        "kernels": ["linear"],
        # We try to find a good number of cross folds to use during
        # intent training, this specifies the max number of folds
        "max_cross_validation_folds": 5,
        # Scoring function used for evaluating the hyper parameters
        # This can be a name or a function (cfr GridSearchCV doc for more info)
        "scoring_function": "f1_weighted",
    }

    @classmethod
    def required_packages(cls) -> List[Text]:
        return ["sklearn"]

    def __init__(
            self,
            component_config: Dict[Text, Any] = None,
            classifier: "GridSearchCV" = None,
            label_encoder: Optional["LabelEncoder"] = None,
    ):
        """Construct a new intent classifier using the sklearn framework."""
        super(SVMClassifier, self).__init__(component_config)
        if label_encoder is not None:
            self.label_encoder = label_encoder
        else:
            self.label_encoder = LabelEncoder()
        self.classifier = classifier

    def train(
            self, training_data: TrainingData, config: NLUModelConfig, **kwargs: Any
    ) -> None:
        """Train the intent classifier on a data set."""
        num_threads = kwargs.get("num_threads", 1)
        labels = [e.get("intent") for e in training_data.intent_examples]
        if len(set(labels)) < 2:
            logger.warning(
                "Can not train an intent classifier. "
                "Need at least 2 different classes. "
                "Skipping training of intent classifier."
            )
        else:
            y = self.transform_labels_str2num(labels)
            X = np.stack([e.get("text_features") for e in training_data.intent_examples])
            self.classifier = self._create_classifier(num_threads, y)
            self.classifier.fit(X, y)

    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        """Persist this model into the passed directory."""
        classifier_file_name = file_name + "_classifier.pkl"
        encoder_file_name = file_name + "_encoder.pkl"
        if self.classifier and self.label_encoder:
            json_pickle(os.path.join(model_dir, encoder_file_name), self.label_encoder.classes_)
            json_pickle(os.path.join(model_dir, classifier_file_name), self.classifier.best_estimator_)
        return {"classifier": classifier_file_name, "encoder": encoder_file_name}

    def transform_labels_str2num(self, labels: List[Text]) -> np.ndarray:
        """Transforms a list of strings into numeric label representation.
        :param labels: List of labels to convert to numeric representation"""
        return self.label_encoder.fit_transform(labels)

    def _create_classifier(self, num_threads, y):
        C = self.component_config["C"]
        kernels = self.component_config["kernels"]
        gamma = self.component_config["gamma"]
        # dirty str fix because sklearn is expecting
        # str not instance of basestr...
        tuned_parameters = [{"C": C, "gamma": gamma, "kernel": [str(k) for k in kernels]}]
        # aim for 5 examples in each fold
        cv_splits = self._num_cv_splits(y)
        return GridSearchCV(
            SVC(C=1, probability=True, class_weight="balanced"),
            param_grid=tuned_parameters,
            n_jobs=num_threads,
            cv=cv_splits,
            scoring=self.component_config["scoring_function"],
            verbose=1,
        )

    def _num_cv_splits(self, y):
        folds = self.component_config["max_cross_validation_folds"]
        return max(2, min(folds, np.min(np.bincount(y)) // 5))
